#include "docrender.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QStandardPaths>

DocRender::DocRender(QObject *parent) : QObject(parent) {}

QString DocRender::cacheDir() const {
    const QString dir = QStandardPaths::writableLocation(QStandardPaths::CacheLocation)
                        + "/docpages";
    QDir().mkpath(dir);
    return dir;
}

QString DocRender::cachePrefix(const QString &path) const {
    const QFileInfo info(path);
    // Name + size + mtime makes the cache key change when the file changes.
    const QString key = info.fileName()
                        + "-" + QString::number(info.size())
                        + "-" + QString::number(info.lastModified().toMSecsSinceEpoch());
    return cacheDir() + "/" + key;
}

QStringList DocRender::images(const QString &path) const {
    const QString prefix = cachePrefix(path);
    const QDir dir(cacheDir());
    QStringList files;
    const QString pattern = QFileInfo(prefix).fileName() + "-*.png";
    for (const QString &name : dir.entryList(QStringList() << pattern,
                                             QDir::Files, QDir::Name)) {
        files << dir.filePath(name);
    }
    return files;
}

bool DocRender::run(const QString &program, const QStringList &args) {
    QProcess proc;
    proc.start(program, args);
    if (!proc.waitForStarted(5000)) return false;
    proc.waitForFinished(30000);
    return proc.exitStatus() == QProcess::NormalExit && proc.exitCode() == 0;
}

void DocRender::render(const QString &path) {
    const QFileInfo info(path);
    const QString suffix = info.suffix().toLower();
    if (suffix != "pdf" && suffix != "ppt" && suffix != "pptx" && suffix != "odp") {
        emit failed("Unsupported file: " + suffix);
        return;
    }

    const QStringList cached = images(path);
    if (!cached.isEmpty()) {
        emit finished(cached);
        return;
    }

    QString pdfPath = path;
    if (suffix != "pdf") {
        if (!run("libreoffice", {"--headless", "--convert-to", "pdf",
                                 "--outdir", cacheDir(), path})) {
            emit failed("Could not convert the presentation");
            return;
        }
        pdfPath = cacheDir() + "/" + info.completeBaseName() + ".pdf";
    }

    if (!run("pdftoppm", {"-png", "-r", "110", pdfPath, cachePrefix(path)})) {
        emit failed("Could not render the PDF");
        return;
    }
    emit finished(images(path));
}

QStringList DocRender::cachedImages(const QString &path) const {
    return images(path);
}
