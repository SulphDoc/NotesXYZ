#include "vault.h"

#include <QDate>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QRegularExpression>
#include <QSettings>
#include <QtMath>
#include <functional>


Vault::Vault(QObject *parent) : QObject(parent) {
    QSettings s;
    m_fontSize = s.value("fontSize", 14).toInt();
    m_dark = s.value("dark", true).toBool();
    m_autosave = s.value("autosave", true).toBool();
    m_accent = s.value("accent", 0).toInt();
    m_focusMode = s.value("focusMode", false).toBool();
    m_onboarded = s.value("onboarded", false).toBool();
    m_rememberFolder = s.value("rememberFolder", true).toBool();
    m_splitRatio = qBound(0.2, s.value("splitRatio", 0.5).toReal(), 0.8);
    m_recent = s.value("recentVaults").toStringList();
    m_typewriter = s.value("typewriter", false).toBool();
    m_readingWidth = qBound(480, s.value("readingWidth", 720).toInt(), 1200);

    m_saveTimer.setSingleShot(true);
    m_saveTimer.setInterval(800);
    connect(&m_saveTimer, &QTimer::timeout, this, [this] { if (m_autosave) save(); });
    connect(&m_watcher, &QFileSystemWatcher::fileChanged,
            this, &Vault::externalChange);

    const QString last = s.value("lastVault").toString();
    if (!last.isEmpty() && QDir(last).exists())
        openVault(QUrl::fromLocalFile(last));

    recordSession();

    // time open: one tick per minute, stored with the day's words (all local, in QSettings)
    m_uptimeTimer.setInterval(60 * 1000);
    connect(&m_uptimeTimer, &QTimer::timeout, this, [this] { updateToday(0, 0, 1); });
    m_uptimeTimer.start();
}

QString Vault::name() const { return m_root.isEmpty() ? QString() : QFileInfo(m_root).fileName(); }

QString Vault::currentName() const { return m_path.isEmpty() ? QString() : QFileInfo(m_path).fileName(); }

QString Vault::cleanName(QString n) {
    n = n.trimmed();
    n.replace(QRegularExpression("[/\\\\:*?\"<>|]"), "-");
    return n;
}

void Vault::setStatus(const QString &s) { m_status = s; emit statusChanged(); }

void Vault::openVault(const QUrl &folder) {
    const QString dir = folder.toLocalFile();
    if (dir.isEmpty() || !QDir(dir).exists()) return;
    save();
    m_root = dir;
    for (const QString &p : m_watcher.files()) m_watcher.removePath(p);
    rememberVault(dir);
    m_path.clear(); m_text.clear(); m_dirty = false; m_filter.clear();
    m_collapsed.clear();
    if (m_rememberFolder) QSettings().setValue("lastVault", dir);
    else QSettings().remove("lastVault");
    emit rootChanged(); emit currentChanged(); emit textChanged(); emit dirtyChanged();
    refresh();
    if (!m_notes.isEmpty()) openFile(m_notes.first());
}

void Vault::clearSavedVault() {
    QSettings().remove("lastVault");
    setStatus("Forgot saved folder");
}

void Vault::openFile(const QString &path) {
    if (path == m_path) { watchCurrent(); return; }
    save();
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    m_loading = true;
    m_path = path;
    m_text = QString::fromUtf8(f.readAll());
    m_savedWords = countWords(m_text);
    m_dirty = false;
    m_loading = false;
    watchCurrent();
    emit currentChanged(); emit textChanged(); emit dirtyChanged();
}

void Vault::setText(const QString &t) {
    if (t == m_text) return;
    m_text = t;
    emit textChanged();
    if (m_loading) return;
    if (!m_dirty) { m_dirty = true; emit dirtyChanged(); }
    m_saveTimer.start();
}

void Vault::save() {
    if (m_path.isEmpty() || !m_dirty) return;
    if (!m_path.isEmpty()) m_watcher.removePath(m_path);
    QFile f(m_path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        watchCurrent(); setStatus("Could not save"); return;
    }
    f.write(m_text.toUtf8());
    watchCurrent();
    m_dirty = false;
    emit dirtyChanged();
    setStatus("Saved " + QFileInfo(m_path).fileName());
    const int words = countWords(m_text);
    const int delta = words - m_savedWords;
    if (delta > 0) recordWords(delta);
    m_savedWords = words;
    recount();
}

QString Vault::findNote(const QString &baseName) const {
    for (const QString &p : m_notes)
        if (QFileInfo(p).completeBaseName().compare(baseName, Qt::CaseInsensitive) == 0) return p;
    return {};
}

void Vault::openByName(const QString &noteName) {
    const QString p = findNote(noteName);
    if (!p.isEmpty()) openFile(p);
}

void Vault::rememberVault(const QString &dir) {
    m_recent.removeAll(dir);
    m_recent.prepend(dir);
    while (m_recent.size() > 5) m_recent.removeLast();
    QSettings s;
    s.setValue("recentVaults", m_recent);
    emit prefsChanged();
}

void Vault::watchCurrent() {
    for (const QString &p : m_watcher.files()) m_watcher.removePath(p);
    if (!m_path.isEmpty() && QFile::exists(m_path)) m_watcher.addPath(m_path);
}

void Vault::reloadCurrent() {
    if (m_path.isEmpty() || m_dirty || m_loading) return;
    QFile f(m_path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    const QString disk = QString::fromUtf8(f.readAll());
    if (disk == m_text) return;
    m_loading = true;
    m_text = disk;
    m_loading = false;
    emit textChanged();
    recount();
    setStatus("Reloaded " + QFileInfo(m_path).fileName());
}
