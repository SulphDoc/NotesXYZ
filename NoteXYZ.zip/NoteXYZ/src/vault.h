#pragma once
#include <QObject>
#include <QSet>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QUrl>
#include <QVariantList>
#include <QVariantMap>
#include <QFileSystemWatcher>

// The whole backend: a vault is just a folder of .md files.
class Vault : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString root READ root NOTIFY rootChanged)
    Q_PROPERTY(QString name READ name NOTIFY rootChanged)
    Q_PROPERTY(QVariantList tree READ tree NOTIFY treeChanged)
    Q_PROPERTY(QString filter READ filter WRITE setFilter NOTIFY treeChanged)
    Q_PROPERTY(QString currentPath READ currentPath NOTIFY currentChanged)
    Q_PROPERTY(QString currentName READ currentName NOTIFY currentChanged)
    Q_PROPERTY(QString text READ text WRITE setText NOTIFY textChanged)
    Q_PROPERTY(int totalWords READ totalWords NOTIFY statsChanged)
    Q_PROPERTY(int noteCount READ noteCount NOTIFY statsChanged)
    Q_PROPERTY(QVariantList activity READ activity NOTIFY statsChanged)
    Q_PROPERTY(int fontSize READ fontSize WRITE setFontSize NOTIFY prefsChanged)
    Q_PROPERTY(bool dark READ dark WRITE setDark NOTIFY prefsChanged)
    Q_PROPERTY(bool autosave READ autosave WRITE setAutosave NOTIFY prefsChanged)
    Q_PROPERTY(int accent READ accent WRITE setAccent NOTIFY prefsChanged)
    Q_PROPERTY(bool focusMode READ focusMode WRITE setFocusMode NOTIFY prefsChanged)
    Q_PROPERTY(bool onboarded READ onboarded WRITE setOnboarded NOTIFY prefsChanged)
    Q_PROPERTY(bool rememberFolder READ rememberFolder WRITE setRememberFolder NOTIFY prefsChanged)
    Q_PROPERTY(qreal splitRatio READ splitRatio WRITE setSplitRatio NOTIFY prefsChanged)
    Q_PROPERTY(QStringList recentVaults READ recentVaults NOTIFY prefsChanged)
    Q_PROPERTY(int trashCount READ trashCount NOTIFY statsChanged)
    Q_PROPERTY(bool dirty READ dirty NOTIFY dirtyChanged)
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    Q_PROPERTY(QString previewHtml READ previewHtml NOTIFY textChanged)
    Q_PROPERTY(QVariantList tags READ tags NOTIFY treeChanged)
    Q_PROPERTY(bool typewriter READ typewriter WRITE setTypewriter NOTIFY prefsChanged)
    Q_PROPERTY(int readingWidth READ readingWidth WRITE setReadingWidth NOTIFY prefsChanged)

public:
    explicit Vault(QObject *parent = nullptr);

    QString root() const { return m_root; }
    QString name() const;
    QVariantList tree() const { return m_tree; }
    QString filter() const { return m_filter; }
    void setFilter(const QString &f);
    QString currentPath() const { return m_path; }
    QString currentName() const;
    QString text() const { return m_text; }
    void setText(const QString &t);
    int totalWords() const { return m_totalWords; }
    int noteCount() const { return m_noteCount; }
    QVariantList activity() const;
    int fontSize() const { return m_fontSize; }
    void setFontSize(int s);
    bool dark() const { return m_dark; }
    void setDark(bool d);
    bool autosave() const { return m_autosave; }
    void setAutosave(bool a);
    int accent() const { return m_accent; }
    void setAccent(int a);
    bool focusMode() const { return m_focusMode; }
    void setFocusMode(bool f);
    bool onboarded() const { return m_onboarded; }
    void setOnboarded(bool o);
    bool rememberFolder() const { return m_rememberFolder; }
    void setRememberFolder(bool r);
    qreal splitRatio() const { return m_splitRatio; }
    void setSplitRatio(qreal r);
    QStringList recentVaults() const { return m_recent; }
    int trashCount() const;
    bool dirty() const { return m_dirty; }
    QString status() const { return m_status; }
    QString previewHtml() const;
    QVariantList tags() const;
    bool typewriter() const { return m_typewriter; }
    void setTypewriter(bool on);
    int readingWidth() const { return m_readingWidth; }
    void setReadingWidth(int w);

    Q_INVOKABLE bool fileExists(const QString &path) const;
    Q_INVOKABLE bool moveNote(const QString &path, const QString &dirPath);

    Q_INVOKABLE void openVault(const QUrl &folder);
    Q_INVOKABLE void clearSavedVault();
    Q_INVOKABLE void openFile(const QString &path);
    Q_INVOKABLE void openByName(const QString &noteName);
    Q_INVOKABLE void newNote(const QString &name);
    Q_INVOKABLE QString todayNote();
    Q_INVOKABLE void duplicateCurrent();
    Q_INVOKABLE void newFolder(const QString &name);
    Q_INVOKABLE void renameCurrent(const QString &newName);
    Q_INVOKABLE void deleteCurrent();
    Q_INVOKABLE bool restoreLastDeleted();
    Q_INVOKABLE void toggleDir(const QString &path);
    Q_INVOKABLE void save();
    Q_INVOKABLE void recordSession();
    Q_INVOKABLE void recordWords(int words);
    Q_INVOKABLE void refresh();
    Q_INVOKABLE void reloadCurrent();
    Q_INVOKABLE QVariantMap graph() const;
    Q_INVOKABLE QStringList allTags() const;
    Q_INVOKABLE QVariantList search(const QString &query) const;
    Q_INVOKABLE QString exportNoteHtml(const QString &path) const;
    Q_INVOKABLE QString exportAllZip();

signals:
    void rootChanged();
    void treeChanged();
    void currentChanged();
    void textChanged();
    void statsChanged();
    void prefsChanged();
    void dirtyChanged();
    void statusChanged();
    void externalChange(const QString &path);

private:
    void collect(const QString &dir, QStringList &dirs, QStringList &notes, QStringList &others) const;
    void buildTree(const QString &dir, int depth);
    void recount();
    void setStatus(const QString &s);
    QString findNote(const QString &baseName) const;
    static QStringList extractLinks(const QString &text);
    static int countWords(const QString &text);
    static QString cleanName(QString n);
    void rememberVault(const QString &dir);
    void watchCurrent();
    void updateToday(int wordsDelta, int sessionsDelta, int minutesDelta = 0);
    static QString markdownToHtml(const QString &md, const QString &title);

    QString m_root, m_path, m_text, m_filter, m_status;
    QVariantList m_tree;
    QStringList m_notes, m_dirs, m_others; // absolute paths
    QStringList m_recent;
    QSet<QString> m_collapsed;
    int m_totalWords = 0, m_noteCount = 0;
    int m_savedWords = 0;
    int m_fontSize = 14, m_accent = 0;
    qreal m_splitRatio = 0.5;
    bool m_dark = true, m_autosave = true, m_dirty = false, m_loading = false, m_focusMode = false;
    bool m_onboarded = false, m_rememberFolder = true, m_typewriter = false;
    int m_readingWidth = 720;
    QString m_lastDeleted, m_lastDeletedFrom;
    QTimer m_saveTimer;
    QTimer m_uptimeTimer;   // ticks once a minute while the app is open
    QFileSystemWatcher m_watcher;
};
