#include "vault.h"
#include <QProcess>
#include <QStandardPaths>

#include <QDate>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QRegularExpression>
#include <QSettings>
#include <QtMath>
#include <functional>


QVariantMap Vault::graph() const {
    struct Node {
        QString id, label, type, parent;
        double x = 0.5, y = 0.5, vx = 0, vy = 0, r = 0.02;
        int links = 0, depth = 0;
    };
    struct Edge { int a, b; bool link; };

    QList<Node> nodes;
    QHash<QString, int> idx;
    QList<Edge> edges;
    int linkEdges = 0;

    if (m_root.isEmpty())
        return {{"nodes", QVariantList()}, {"edges", QVariantList()}, {"linkCount", 0}};

    auto add = [&](const QString &id, const QString &label, const QString &type, const QString &parent) {
        Node n;
        n.id = id; n.label = label; n.type = type; n.parent = parent;
        n.depth = idx.contains(parent) ? nodes[idx[parent]].depth + 1 : 0;
        n.r = type == "folder" ? 0.030 : (type == "note" ? 0.017 : 0.014);
        idx[id] = nodes.size();
        nodes.append(n);
    };

    add(m_root, name(), "folder", QString());
    for (const QString &d : m_dirs)
        add(d, QFileInfo(d).fileName(), "folder", QFileInfo(d).absolutePath());
    for (const QString &p : m_notes)
        add(p, QFileInfo(p).fileName(), "note", QFileInfo(p).absolutePath());
    for (const QString &p : m_others)
        add(p, QFileInfo(p).fileName(), "other", QFileInfo(p).absolutePath());

    // containment edges follow the folder tree
    for (int i = 1; i < nodes.size(); ++i)
        edges.append({idx.value(nodes[i].parent, 0), i, false});

    // wiki-link edges between notes
    for (const QString &p : m_notes) {
        QString txt;
        if (p == m_path) txt = m_text;
        else { QFile f(p); if (f.open(QIODevice::ReadOnly | QIODevice::Text)) txt = QString::fromUtf8(f.readAll()); }
        const int from = idx[p];
        for (const QString &l : extractLinks(txt)) {
            const QString target = findNote(l);
            if (target.isEmpty() || target == p) continue;
            const int to = idx[target];
            edges.append({from, to, true});
            nodes[from].links++; nodes[to].links++;
            nodes[from].r = qMax(nodes[from].r, 0.017 + qMin(nodes[from].links, 8) * 0.0025);
            nodes[to].r = qMax(nodes[to].r, 0.017 + qMin(nodes[to].links, 8) * 0.0025);
            ++linkEdges;
        }
    }

    // seed a tidy radial layout: children fan out around their parent
    QHash<QString, QList<int>> children;
    for (int i = 1; i < nodes.size(); ++i)
        children[nodes[i].parent].append(i);

    std::function<void(int, double, double, double)> place =
        [&](int i, double angle, double spread, double radius) {
            const double jitter = ((qHash(nodes[i].id) % 2000) / 2000.0 - 0.5) * 0.05;
            const double a = angle + jitter;
            nodes[i].x = 0.5 + radius * qCos(a);
            nodes[i].y = 0.5 + radius * qSin(a);
            const QList<int> &ch = children[nodes[i].id];
            if (ch.isEmpty()) return;
            const double nextRadius = qMin(radius + 0.13, 0.40);
            const double nextSpread = qMax(spread * 0.55, 0.85);
            for (int k = 0; k < ch.size(); ++k) {
                const double childAngle = a - spread / 2 + (k + 0.5) * spread / ch.size();
                place(ch[k], childAngle, nextSpread, nextRadius);
            }
        };
    place(0, -M_PI / 2, 2 * M_PI, 0.0);

    // refine: repulsion + collision, tree springs, weaker link springs, centering
    const int N = nodes.size();
    for (int iter = 0; iter < 260; ++iter) {
        for (int i = 0; i < N; ++i)
            for (int j = i + 1; j < N; ++j) {
                double dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y;
                double d2 = dx * dx + dy * dy + 0.0006, d = qSqrt(d2);
                double f = qMin(0.00045 / d2, 0.02);
                const double minDist = nodes[i].r + nodes[j].r + 0.012;
                if (d < minDist) f += (minDist - d) * 0.08;
                nodes[i].vx += dx / d * f; nodes[i].vy += dy / d * f;
                nodes[j].vx -= dx / d * f; nodes[j].vy -= dy / d * f;
            }

        for (const Edge &e : edges) {
            Node &a = nodes[e.a], &b = nodes[e.b];
            const double dx = b.x - a.x, dy = b.y - a.y;
            const double d = qSqrt(dx * dx + dy * dy) + 1e-6;
            const double target = e.link ? 0.20 : 0.125;
            const double k = e.link ? 0.007 : 0.035;
            const double f = (d - target) * k;
            a.vx += dx / d * f; a.vy += dy / d * f;
            b.vx -= dx / d * f; b.vy -= dy / d * f;
        }

        for (auto &n : nodes) {
            n.vx += (0.5 - n.x) * 0.0025;
            n.vy += (0.5 - n.y) * 0.0025;
            n.vx = qBound(-0.02, n.vx, 0.02);
            n.vy = qBound(-0.02, n.vy, 0.02);
            n.x += n.vx; n.y += n.vy;
            n.vx *= 0.6; n.vy *= 0.6;
        }
    }

    double minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
    for (const auto &n : nodes) {
        minx = qMin(minx, n.x); maxx = qMax(maxx, n.x);
        miny = qMin(miny, n.y); maxy = qMax(maxy, n.y);
    }
    const double sx = qMax(maxx - minx, 1e-3), sy = qMax(maxy - miny, 1e-3);

    QVariantList vn, ve;
    for (const auto &n : nodes) {
        QVariantMap m;
        m["id"] = n.id; m["label"] = n.label; m["type"] = n.type;
        m["links"] = n.links; m["depth"] = n.depth;
        m["current"] = (n.id == m_path);
        m["x"] = 0.07 + 0.86 * (n.x - minx) / sx;
        m["y"] = 0.09 + 0.82 * (n.y - miny) / sy;
        vn << m;
    }
    for (const Edge &e : edges) {
        QVariantMap m;
        m["a"] = e.a; m["b"] = e.b;
        m["type"] = e.link ? "link" : "tree";
        ve << m;
    }
    return {{"nodes", vn}, {"edges", ve}, {"linkCount", linkEdges}};
}

QStringList Vault::allTags() const {
    static const QRegularExpression re("#[\\w-]+");
    QStringList out;
    QSet<QString> seen;
    for (const QString &p : m_notes) {
        QString txt;
        if (p == m_path) txt = m_text;
        else {
            QFile f(p);
            if (f.open(QIODevice::ReadOnly | QIODevice::Text))
                txt = QString::fromUtf8(f.readAll());
        }
        auto it = re.globalMatch(txt);
        while (it.hasNext()) {
            const QString tag = it.next().captured();
            const QString key = tag.toLower();
            if (seen.contains(key)) continue;
            seen.insert(key);
            out << tag;
        }
    }
    out.sort(Qt::CaseInsensitive);
    return out;
}

QVariantList Vault::search(const QString &query) const {
    QVariantList out;
    const QString q = query.trimmed();
    if (q.isEmpty()) return out;
    for (const QString &p : m_notes) {
        QFile f(p);
        if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) continue;
        const QString body = QString::fromUtf8(f.readAll());
        const int at = body.indexOf(q, Qt::CaseInsensitive);
        if (at < 0) continue;
        const int from = qMax(0, at - 34);
        QString snip = body.mid(from, 96).replace('\n', ' ').simplified();
        if (from > 0) snip.prepend("…");
        if (from + 96 < body.size()) snip.append("…");
        QVariantMap m;
        m["path"] = p;
        m["name"] = QFileInfo(p).completeBaseName();
        m["snippet"] = snip;
        out << m;
        if (out.size() >= 30) break;
    }
    return out;
}

QString Vault::markdownToHtml(const QString &md, const QString &title) {
    const bool dark = QSettings().value("dark", true).toBool();
    const QString fg = dark ? "#f2f2f2" : "#1f1f1f";
    const QString codeBg = dark ? "#32302f" : "#f2e5bc";
    const QString link = dark ? "#83a598" : "#076678";
    QString css = QStringLiteral(
        "body{font:15px/1.65 system-ui,sans-serif;color:%1;max-width:760px;"
        "margin:64px auto;padding:0 24px}h1,h2,h3{font-weight:650;line-height:1.25}"
        "h1{font-size:30px}h2{font-size:22px;margin-top:32px}h3{font-size:18px}"
        "p{margin:12px 0}code{background:%2;padding:2px 5px;border-radius:4px}"
        "a{color:%3;text-decoration:none}a:hover{text-decoration:underline}"
        "strong{font-weight:650}").arg(fg, codeBg, link);
    QString body;
    for (const QString &raw : md.split('\n')) {
        const QString line = raw.trimmed();
        if (line.isEmpty()) { body.append("<p></p>"); continue; }
        if (line.startsWith("### ")) { body.append("<h3>" + line.mid(4).toHtmlEscaped() + "</h3>"); continue; }
        if (line.startsWith("## ")) { body.append("<h2>" + line.mid(3).toHtmlEscaped() + "</h2>"); continue; }
        if (line.startsWith("# ")) { body.append("<h1>" + line.mid(2).toHtmlEscaped() + "</h1>"); continue; }
        QString t = line.toHtmlEscaped();
        QRegularExpression link("\\[\\[([^\\]]+)\\]\\]");
        t.replace(link, "<a href=\"wiki:\\1\">\\1</a>");
        QRegularExpression bold("\\*\\*([^*]+)\\*\\*");
        t.replace(bold, "<strong>\\1</strong>");
        QRegularExpression code("`([^`]+)`");
        t.replace(code, "<code>\\1</code>");
        body.append("<p>" + t + "</p>");
    }
    return "<!doctype html><html><head><meta charset=\"utf-8\"><title>" +
           title.toHtmlEscaped() + "</title><style>" + css +
           "</style></head><body>" + body + "</body></html>";
}

QString Vault::exportNoteHtml(const QString &path) const {
    if (path.isEmpty()) return {};
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return {};
    const QFileInfo info(path);
    const QString out = info.dir().filePath(info.completeBaseName() + ".html");
    QFile o(out);
    if (!o.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) return {};
    o.write(markdownToHtml(QString::fromUtf8(f.readAll()), info.completeBaseName()).toUtf8());
    return out;
}

QString Vault::previewHtml() const {
    return markdownToHtml(m_text, currentName());
}

QVariantList Vault::tags() const {
    QVariantList out;
    for (const QString &t : allTags()) out << t;
    return out;
}

QString Vault::exportAllZip() {
    if (m_root.isEmpty()) return QString();
    const QString dest = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)
                         + "/notexyz-backup.zip";
    // Python's zipfile is present on every target machine here and handles
    // UTF-8 names and recursion without pulling in a new app dependency.
    // Paths go as argv — never interpolated into the script (a quote in a
    // folder name would otherwise break out and run arbitrary Python).
    const QString script = QStringLiteral(
        "import zipfile,os,sys\n"
        "z=zipfile.ZipFile(sys.argv[1],'w',zipfile.ZIP_DEFLATED)\n"
        "r=sys.argv[2]\n"
        "for root,dirs,files in os.walk(r):\n"
        " dirs[:]=[d for d in dirs if not d.startswith('.')]\n"
        " for f in files:\n"
        "  if f.endswith('.zip'): continue\n"
        "  p=os.path.join(root,f)\n"
        "  z.write(p,os.path.relpath(p,r))\n"
        "z.close()\n"
    );
    QProcess proc;
    proc.start("python3", {"-c", script, dest, m_root});
    if (!proc.waitForStarted(3000) || !proc.waitForFinished(15000)) {
        setStatus("Could not create the backup");
        return QString();
    }
    if (proc.exitCode() != 0) {
        setStatus("Could not create the backup");
        return QString();
    }
    setStatus("Backed up " + QString::number(m_noteCount) + " notes");
    return dest;
}
