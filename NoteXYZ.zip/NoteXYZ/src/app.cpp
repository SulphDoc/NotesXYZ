#include "app.h"

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QFontDatabase>
#include <QFile>
#include <QIcon>
#include <QQmlError>
#include <QQmlComponent>
#include <QUrl>
#include <cstdio>

#include "vault.h"
#include "docrender.h"

int appRun(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    app.setOrganizationName("notes");
    app.setApplicationName("notes");
    QQuickStyle::setStyle("Basic");

    const QString fontPath = QStringLiteral(":/qt/qml/NotesApp/qml/fonts/NoteXYZIcons.ttf");
    if (QFontDatabase::addApplicationFont(fontPath) < 0)
        std::fprintf(stderr, "Could not load icon font %s\n", qPrintable(fontPath));

    const QString iconPath = QStringLiteral(":/qt/qml/NotesApp/qml/images/logo-color.png");
    if (QFile::exists(iconPath))
        app.setWindowIcon(QIcon(iconPath));

    Vault vault;
    DocRender docRender;
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("vault", &vault);
    engine.rootContext()->setContextProperty("docRender", &docRender);
    engine.rootContext()->setContextProperty("uiFontFamily", app.font().family());
    QQmlComponent themeComp(&engine, QUrl("qrc:/qt/qml/NotesApp/qml/ThemeObject.qml"));
    QObject *themeObj = themeComp.create();
    if (themeObj) engine.rootContext()->setContextProperty("AppTheme", themeObj);
    else std::fprintf(stderr, "Theme error: %s\n", qPrintable(themeComp.errorString()));
    QObject::connect(&engine, &QQmlApplicationEngine::warnings,
                     &app, [](const QList<QQmlError> &errs) {
        for (const QQmlError &e : errs)
            std::fprintf(stderr, "QML: %s\n", qPrintable(e.toString()));
    });
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
                     &app, [] {
        std::fprintf(stderr, "QML object creation failed\n");
        QCoreApplication::exit(1);
    }, Qt::QueuedConnection);
    engine.loadFromModule("NotesApp", "Main");
    return app.exec();
}
