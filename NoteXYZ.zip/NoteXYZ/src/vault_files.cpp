#include "vault.h"

#include <QDate>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QRegularExpression>
#include <QSettings>
#include <QtMath>
#include <functional>


void Vault::collect(const QString &dirPath, QStringList &dirs, QStringList &notes, QStringList &others) const {
    QDir dir(dirPath);
    const auto ds = dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name | QDir::IgnoreCase);
    for (const QFileInfo &d : ds) {
        if (d.fileName().startsWith('.')) continue;
        dirs << d.absoluteFilePath();
        collect(d.absoluteFilePath(), dirs, notes, others);
    }
    const auto fs = dir.entryInfoList(QDir::Files, QDir::Name | QDir::IgnoreCase);
    for (const QFileInfo &f : fs) {
        if (f.fileName().startsWith('.')) continue;
        const QString suf = f.suffix().toLower();
        if (suf == "md" || suf == "markdown") notes << f.absoluteFilePath();
        else others << f.absoluteFilePath();
    }
}

void Vault::buildTree(const QString &dirPath, int depth) {
    QDir dir(dirPath);
    const auto ds = dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name | QDir::IgnoreCase);
    for (const QFileInfo &d : ds) {
        if (d.fileName().startsWith('.')) continue;
        const bool open = !m_collapsed.contains(d.absoluteFilePath());
        QVariantMap m;
        m["name"] = d.fileName(); m["path"] = d.absoluteFilePath();
        m["depth"] = depth; m["dir"] = true; m["expanded"] = open;
        m_tree << m;
        if (open) buildTree(d.absoluteFilePath(), depth + 1);
    }
    const auto fs = dir.entryInfoList({"*.md", "*.markdown"}, QDir::Files, QDir::Name | QDir::IgnoreCase);
    for (const QFileInfo &f : fs) {
        if (f.fileName().startsWith('.')) continue;
        QVariantMap m;
        m["name"] = f.fileName(); m["path"] = f.absoluteFilePath();
        m["depth"] = depth; m["dir"] = false; m["expanded"] = false;
        m_tree << m;
    }
}

void Vault::refresh() {
    m_tree.clear(); m_notes.clear(); m_dirs.clear(); m_others.clear();
    if (!m_root.isEmpty()) {
        collect(m_root, m_dirs, m_notes, m_others);
        if (m_filter.trimmed().isEmpty()) {
            buildTree(m_root, 0);
        } else {
            const QString f = m_filter.trimmed();
            for (const QString &p : std::as_const(m_notes)) {
                bool hit = QFileInfo(p).fileName().contains(f, Qt::CaseInsensitive);
                if (!hit) {
                    QFile file(p);
                    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
                        hit = QString::fromUtf8(file.readAll()).contains(f, Qt::CaseInsensitive);
                }
                if (!hit) continue;
                QVariantMap m;
                m["name"] = QFileInfo(p).fileName(); m["path"] = p;
                m["depth"] = 0; m["dir"] = false; m["expanded"] = false;
                m_tree << m;
            }
        }
    }
    recount();
    emit treeChanged();
}

void Vault::toggleDir(const QString &path) {
    if (m_collapsed.contains(path)) m_collapsed.remove(path); else m_collapsed.insert(path);
    refresh();
}

void Vault::recount() {
    int words = 0;
    for (const QString &p : std::as_const(m_notes)) {
        if (p == m_path) { words += countWords(m_text); continue; }
        QFile f(p);
        if (f.open(QIODevice::ReadOnly | QIODevice::Text))
            words += countWords(QString::fromUtf8(f.readAll()));
    }
    m_totalWords = words; m_noteCount = m_notes.size();
    emit statsChanged();
}

int Vault::countWords(const QString &t) {
    return t.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts).size();
}

void Vault::newNote(const QString &rawName) {
    if (m_root.isEmpty()) return;
    QString n = cleanName(rawName);
    if (n.isEmpty()) n = "Untitled";
    if (n.endsWith(".md", Qt::CaseInsensitive)) n.chop(3);
    // new notes go next to the open note, or in the vault root
    const QString base = m_path.isEmpty() ? m_root : QFileInfo(m_path).absolutePath();
    QString path = QDir(base).filePath(n + ".md");
    int i = 2;
    while (QFile::exists(path)) path = QDir(base).filePath(QString("%1 %2.md").arg(n).arg(i++));
    QFile f(path);
    if (f.open(QIODevice::WriteOnly | QIODevice::Text))
        f.write(QString("# %1\n\n").arg(QFileInfo(path).completeBaseName()).toUtf8());
    f.close();
    refresh();
    openFile(path);
    setStatus("Created " + QFileInfo(path).fileName());
}

QString Vault::todayNote() {
    if (m_root.isEmpty()) return {};
    const QString name = QDate::currentDate().toString("yyyy-MM-dd");
    const QString path = QFileInfo(QDir(m_root).filePath(name + ".md")).absoluteFilePath();
    if (!QFile::exists(path)) {
        QFile f(path);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text))
            f.write(QString("# %1\n\n").arg(name).toUtf8());
        f.close();
        refresh();
    }
    return path;
}

void Vault::duplicateCurrent() {
    if (m_path.isEmpty()) return;
    const QString name = QFileInfo(m_path).completeBaseName();
    const QString base = QFileInfo(m_path).absolutePath();
    QString path = QDir(base).filePath(name + " copy.md");
    int i = 2;
    while (QFile::exists(path))
        path = QDir(base).filePath(QString("%1 copy %2.md").arg(name).arg(i++));
    QFile f(path);
    if (f.open(QIODevice::WriteOnly | QIODevice::Text))
        f.write(m_text.toUtf8());
    f.close();
    refresh();
    openFile(path);
    setStatus("Duplicated " + name);
}

void Vault::newFolder(const QString &rawName) {
    if (m_root.isEmpty()) return;
    const QString n = cleanName(rawName);
    if (n.isEmpty()) return;
    QDir(m_root).mkpath(n);
    refresh();
    setStatus("Created folder " + n);
}

void Vault::renameCurrent(const QString &rawName) {
    if (m_path.isEmpty()) return;
    save();
    QString n = cleanName(rawName);
    if (n.isEmpty()) return;
    if (!n.endsWith(".md", Qt::CaseInsensitive)) n += ".md";
    const QString np = QFileInfo(m_path).dir().filePath(n);
    if (np != m_path && QFile::exists(np)) { setStatus("A note with that name exists"); return; }
    if (QFile::rename(m_path, np)) {
        m_path = np;
        refresh();
        emit currentChanged();
        setStatus("Renamed to " + n);
    }
}

void Vault::deleteCurrent() {
    if (m_path.isEmpty()) return;
    const QString gone = QFileInfo(m_path).fileName();
    m_saveTimer.stop();
    m_watcher.removePath(m_path);

    const QString trashDir = QDir(m_root).filePath(".trash");
    QDir().mkpath(trashDir);
    QString dest = QDir(trashDir).filePath(gone);
    int i = 2;
    while (QFile::exists(dest))
        dest = QDir(trashDir).filePath(QString("%1 %2.%3")
            .arg(QFileInfo(m_path).completeBaseName()).arg(i++)
            .arg(QFileInfo(m_path).suffix()));

    m_lastDeletedFrom = QFileInfo(m_path).absolutePath();
    if (QFile::rename(m_path, dest)) m_lastDeleted = dest;
    else { QFile::remove(m_path); m_lastDeleted.clear(); m_lastDeletedFrom.clear(); }

    m_path.clear(); m_text.clear(); m_dirty = false;
    emit currentChanged(); emit textChanged(); emit dirtyChanged(); emit statsChanged();
    refresh();
    if (!m_notes.isEmpty()) openFile(m_notes.first());
    setStatus(m_lastDeleted.isEmpty() ? "Deleted " + gone : "Deleted " + gone + " · Ctrl+Z to undo");
}

QStringList Vault::extractLinks(const QString &text) {
    static const QRegularExpression re("\\[\\[([^\\]|#]+)(?:[|#][^\\]]*)?\\]\\]");
    QStringList out;
    auto it = re.globalMatch(text);
    while (it.hasNext()) {
        const QString l = it.next().captured(1).trimmed();
        if (!l.isEmpty() && !out.contains(l, Qt::CaseInsensitive)) out << l;
    }
    return out;
}

int Vault::trashCount() const {
    if (m_root.isEmpty()) return 0;
    return QDir(QDir(m_root).filePath(".trash"))
        .entryList(QDir::Files | QDir::NoDotAndDotDot).size();
}

bool Vault::restoreLastDeleted() {
    if (m_lastDeleted.isEmpty() || !QFile::exists(m_lastDeleted)) return false;
    const QString name = QFileInfo(m_lastDeleted).fileName();
    const QString back = QDir(m_lastDeletedFrom.isEmpty() ? m_root : m_lastDeletedFrom).filePath(name);
    if (QFile::exists(back)) { setStatus("A note with that name already exists"); return false; }
    if (!QFile::rename(m_lastDeleted, back)) { setStatus("Could not restore " + name); return false; }
    m_lastDeleted.clear(); m_lastDeletedFrom.clear();
    refresh();
    openFile(back);
    setStatus("Restored " + name);
    return true;
}

bool Vault::fileExists(const QString &path) const {
    return QFileInfo::exists(path);
}

bool Vault::moveNote(const QString &path, const QString &dirPath) {
    if (m_root.isEmpty() || path.isEmpty() || dirPath.isEmpty()) return false;
    // A drop can carry any text — never move a file from outside this vault.
    const QString root = QDir(m_root).canonicalPath();
    const QFileInfo note(path);
    const QString noteDir = note.absoluteDir().canonicalPath();
    if (!note.exists() || note.suffix().toLower() != "md") return false;
    if (noteDir != root && !noteDir.startsWith(root + "/")) return false;

    const QDir target(dirPath);
    if (!target.exists()) return false;
    const QString destDir = target.canonicalPath();
    if (destDir != root && !destDir.startsWith(root + "/")) return false;

    const QString dest = target.filePath(note.fileName());
    if (dest == path || QFile::exists(dest)) {
        setStatus("A note with that name exists");
        return false;
    }
    if (!QFile::rename(path, dest)) {
        setStatus("Could not move the note");
        return false;
    }
    if (m_path == path) m_path = dest;
    m_watcher.removePath(path);
    refresh();
    if (m_path == dest) { watchCurrent(); emit currentChanged(); }
    setStatus("Moved " + note.completeBaseName());
    return true;
}
