#ifndef DOCRENDER_H
#define DOCRENDER_H

#include <QObject>
#include <QStringList>

class DocRender : public QObject {
    Q_OBJECT
public:
    explicit DocRender(QObject *parent = nullptr);

    Q_INVOKABLE void render(const QString &path);
    Q_INVOKABLE QStringList cachedImages(const QString &path) const;

signals:
    void finished(QStringList images);
    void failed(QString message);

private:
    QString cacheDir() const;
    QString cachePrefix(const QString &path) const;
    bool run(const QString &program, const QStringList &args);
    QStringList images(const QString &path) const;
};

#endif
