#include "app.h"

int main(int argc, char *argv[]) {
    return appRun(argc, argv);
}
