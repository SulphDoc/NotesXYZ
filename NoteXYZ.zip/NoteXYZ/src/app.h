#ifndef APP_H
#define APP_H

int appRun(int argc, char *argv[]);

#endif
