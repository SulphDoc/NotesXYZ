#include "vault.h"

#include <QDate>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QRegularExpression>
#include <QSettings>
#include <QtMath>
#include <functional>

static QString activityDateKey(const QDate &d) { return d.toString("yyyy-MM-dd"); }


void Vault::setFontSize(int s) {
    s = qBound(10, s, 32);
    if (s == m_fontSize) return;
    m_fontSize = s; QSettings().setValue("fontSize", s); emit prefsChanged();
}

void Vault::setDark(bool d) {
    if (d == m_dark) return;
    m_dark = d; QSettings().setValue("dark", d); emit prefsChanged();
}

void Vault::setAutosave(bool a) {
    if (a == m_autosave) return;
    m_autosave = a; QSettings().setValue("autosave", a); emit prefsChanged();
}

void Vault::setAccent(int a) {
    a = qBound(0, a, 2);
    if (a == m_accent) return;
    m_accent = a; QSettings().setValue("accent", a); emit prefsChanged();
}

void Vault::setFocusMode(bool f) {
    if (f == m_focusMode) return;
    m_focusMode = f; QSettings().setValue("focusMode", f); emit prefsChanged();
}

void Vault::setOnboarded(bool o) {
    if (o == m_onboarded) return;
    m_onboarded = o; QSettings().setValue("onboarded", o); emit prefsChanged();
}

void Vault::setRememberFolder(bool r) {
    if (r == m_rememberFolder) return;
    m_rememberFolder = r; QSettings().setValue("rememberFolder", r); emit prefsChanged();
}

void Vault::setSplitRatio(qreal r) {
    r = qBound(0.2, r, 0.8);
    if (r == m_splitRatio) return;
    m_splitRatio = r; QSettings().setValue("splitRatio", r); emit prefsChanged();
}

void Vault::setFilter(const QString &f) {
    if (f == m_filter) return;
    m_filter = f;
    refresh();
}

QVariantList Vault::activity() const {
    QHash<QString, QVariantMap> byDate;
    const QVariantList stored = QSettings().value("activity").toList();
    for (const QVariant &v : std::as_const(stored)) {
        const QVariantMap m = v.toMap();
        const QString key = m.value("date").toString();
        if (!key.isEmpty()) byDate.insert(key, m);
    }

    const QDate today = QDate::currentDate();
    const QDate first = today.addDays(-364);          // rolling year: 365 days ending today
    QVariantList out;
    for (QDate d = first; d <= today; d = d.addDays(1)) {
        const QString key = activityDateKey(d);
        QVariantMap m = byDate.value(key);
        m["date"] = key;
        m["words"] = m.value("words", 0).toInt();
        m["sessions"] = m.value("sessions", 0).toInt();
        m["minutes"] = m.value("minutes", 0).toInt();
        out << m;
    }
    return out;
}

void Vault::updateToday(int wordsDelta, int sessionsDelta, int minutesDelta) {
    QSettings s;
    QVariantList list = s.value("activity").toList();
    const QString key = activityDateKey(QDate::currentDate());

    int at = -1;
    for (int i = 0; i < list.size(); ++i) {
        if (list.at(i).toMap().value("date").toString() == key) { at = i; break; }
    }

    QVariantMap m = at >= 0 ? list.at(at).toMap() : QVariantMap();
    m["date"] = key;
    m["words"] = m.value("words", 0).toInt() + wordsDelta;
    m["sessions"] = m.value("sessions", 0).toInt() + sessionsDelta;
    m["minutes"] = m.value("minutes", 0).toInt() + minutesDelta;
    if (at >= 0) list[at] = m; else list.append(m);

    while (list.size() > 366) {
        int oldest = 0;
        QString oldestDate = list.first().toMap().value("date").toString();
        for (int i = 1; i < list.size(); ++i) {
            const QString d = list.at(i).toMap().value("date").toString();
            if (d < oldestDate) { oldestDate = d; oldest = i; }
        }
        list.removeAt(oldest);
    }

    s.setValue("activity", list);
    emit statsChanged();
}

void Vault::recordSession() { updateToday(0, 1); }

void Vault::recordWords(int words) {
    if (words > 0) updateToday(words, 0);
}

void Vault::setTypewriter(bool on) {
    if (m_typewriter == on) return;
    m_typewriter = on;
    QSettings s;
    s.setValue("typewriter", on);
    emit prefsChanged();
}

void Vault::setReadingWidth(int w) {
    w = qBound(480, w, 1200);
    if (m_readingWidth == w) return;
    m_readingWidth = w;
    QSettings s;
    s.setValue("readingWidth", w);
    emit prefsChanged();
}
