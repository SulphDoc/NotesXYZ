# NoteXYZ

Plain Markdown notes in a folder you own. Qt 6 / QML, C++17 backend.

## Build
```
sudo pacman -S qt6-base qt6-declarative cmake   # or your distro's equivalent
cmake -B build -S . && cmake --build build -j
./build/notes
```
Needs Qt 6.5+ (Quick, QuickControls2, QuickDialogs2).

## Project layout
- `src/` C++ backend (`Vault`): files, tree, search, graph, preferences
- `qml/` UI. One file per component. See `AGENT.md` for the design rules
- `qml/fonts/NoteXYZIcons.ttf` Adwaita icon font (generated)
- `tools/` icon font builder, logo sources (`qml/images/mark-*.svg`), QML lint

## Tools
```
python3 tools/lint_qml.py            # static checks, run before committing
python3 tools/build_icon_font.py     # after editing tools/icons.json (needs: pip install fonttools)
```

## Credits
Icons: GNOME Adwaita icon theme, CC-BY-SA 3.0 / LGPL 3 (`tools/adwaita-svg/COPYRIGHT-adwaita-icon-theme`).
