# AGENT.md: how to polish NoteXYZ

Read this fully before changing the UI. It is the contract between the design and the code.

> **Status:** this code was refactored without access to a Qt compiler. The first build may show small QML
> errors. Fix them, run `python3 tools/lint_qml.py`, and keep going.

## 1. The look: "GNOME and macOS had a child"

Calm, flat, quiet. The app should disappear around the text.

| Take from GNOME (Adwaita) | Take from macOS |
|---|---|
| Flat full-width header bar with a hairline under it | Translucent fills for hover, fields and tracks (they adapt to any surface) |
| Adwaita symbolic icons, 16px grid | Segmented control with a sliding thumb |
| Dark toast pill in both themes | Soft layered shadows on floating things only |
| Tinted accent selection (not a loud fill) | Source-list sidebar: rounded rows, quiet hover |
| Sentence-case headings, no ALL CAPS labels | Command palette top-centre, instant, no animation |
| Real focus rings (2px accent) | Overlay scrollbars that fade when idle |

Never add: gradients on UI chrome, glows, heavy borders, bouncy animation, emoji, ALL CAPS, bold everywhere.

## 2. Hard rules (check every change against these)

1. **No literal colours, radii, sizes, spacing or durations in components.** Use `AppTheme.*`. If a token is missing, add it to `ThemeObject.qml` with a comment; do not inline a number. `tools/lint_qml.py` warns about literals.
2. **Three control heights only:** `ctrlSm` 24, `ctrlMd` 32, `ctrlLg` 40. Rows, buttons, fields and segmented tracks use one of them. Nothing is 26, 30, 34, 38 or 44.
3. **Radius follows size:** `radiusSm` (6) for 24px controls, `radiusMd` (8) for 32px controls, `radiusLg` (12) for cards, dialogs, popovers, toasts. Pills (`width / 2`) only for dots, swatches and scrollbar thumbs. Heatmap cells use `radiusCell`.
4. **Nested corners are concentric:** `inner radius = outer radius - gap`. Use `AppTheme.inner(outer, gap)`. A 12px toast with a 4px gap holds an 8px button; an 8px segmented track with a 2px gap holds a 6px thumb. This is the number-one cause of "something feels off".
5. **4pt spacing grid:** `space1..space6` (4, 8, 12, 16, 24, 32). A label sits closer to its own group than to the previous one (`Group` in Settings does this).
6. **Icons are 16px** (24 or 32 for empty-state art). Adwaita icons are drawn on a 16px grid and blur at 17, 19, 20.
7. **One level of emphasis per row:** a row is either hovered or selected. Hover (`AppTheme.hover`) must always be weaker than selected (`accentSoft`).
8. **Dividers are full-bleed hairlines** (`AppTheme.line`, 1px) between bars and content. No inset floating lines.
9. **Hover is one layer.** No stacked overlays, and no press-scaling on buttons or text. Press = a slightly stronger fill.
10. **Motion:** `motionFast` (120ms) for hover, thumb and toast, `motionSlow` (220ms) for fades. Nothing loops. Nothing animates on a keyboard action (palette, shortcuts).
11. **Autosave is silent.** Toasts are only for things the user asked for, or errors. Saved state lives in the status bar.
12. **One place per kind of control.** Sidebar: brand, search, tree, footer (vault, activity, settings). Top bar: title, create (new note, new folder), note actions (rename, delete), view switcher. Status bar: information only, no buttons. Do not add a fifth toolbar.

## 3. Components: use these, never re-implement

| File | Use for |
|---|---|
| `ToolBtn` | Every button. `primary`, `danger`, `active`, `iconOnly`, `alignLeft`, `tip`. |
| `AppField` | Every text input (`leadingIcon`, `clearable`). |
| `AppCheckBox` | Every checkbox. |
| `Segmented` | Mutually exclusive icon choices (view switcher, light/dark). |
| `AppDialog` | Frame for any modal dialog (see `NameDialog`, `DeleteDialog`). |
| `Scrim` + a card with `Elevation` | Non-Popup overlays (palette, settings, onboarding). `Elevation` is a real blurred shadow (`MultiEffect`, Qt 6.5+); the caster is inset 1px so no dark fringe shows. Dialogs use `lift: 1`, toasts and popovers `0.6`. |
| `ActivityDialog` | Year heatmap (words written, time open, streak). Reads `vault.activity`. |
| `Toast` | Transient feedback. `toast.show(text, actionText)`. |
| `EmptyState` | Every "nothing here yet" state (icon, title, hint). |
| `SectionLabel` | Headings above controls. |
| `Logo` | The app mark (geometric emblem). |
| `Keycap` / `ShortcutList` | Shortcut display. The list lives only in `ShortcutList.qml`. |
| `Tip` | Tooltips (`ToolBtn` already includes one). |
| `ThinScrollBar` | `ScrollBar.vertical: ThinScrollBar {}` on every scrollable. |

If you need a pattern three times, make a component. If one of the above almost fits, extend it with a property rather than copying it.

## 4. Tokens at a glance (`ThemeObject.qml`)

- **Surfaces:** `bg` (content) < `panel` (sidebar) < `surface` (dialogs). `thumb`, `toastBg`.
- **Fills:** `hover`, `pressed`, `trough` (translucent, work on any surface).
- **Lines:** `line` (hairline), `borderStrong`.
- **Text:** `fg`, `muted`, `faint` (all >= 4.5:1 on their surfaces; keep it so).
- **Accent:** `accent` (text/icons), `accentFill` (buttons), `accentHover`, `accentSoft` (selection), `accentOn`. Three palettes: Teal (default), Blue, Coral.
- **Status:** `danger`, `dangerSoft`, `warning`.
- **Type scale:** 11 / 12 / 13 / 14 / 16 / 20 / 32. Body is `fontMd` (13). Titles `fontXl` DemiBold. Never Bold below `fontXxl`.

## 5. Icons (Adwaita, compiled into a font)

- Source SVGs live in `tools/adwaita-svg/`, the mapping in `tools/icons.json`.
- To add an icon: copy the `*-symbolic.svg` into `tools/adwaita-svg/`, add `"name": "file.svg"` to `tools/icons.json`, run `python3 tools/build_icon_font.py`. It rewrites `qml/fonts/NoteXYZIcons.ttf` and the glyph table in `Icon.qml`. Never edit the table by hand.
- Use the icon's *meaning*, not whatever looks close. One meaning = one icon everywhere (the old app used the same glyph for "preview" and "focus mode").
- Source: Adwaita icon theme, CC-BY-SA 3.0 / LGPL 3 (credited in Settings > About).

## 6. How to polish (workflow)

1. **Get a screenshot** (dark and light) of the exact screen. Compare against sections 1 and 2; list violations before touching code.
2. Fix at the root: a token, a component, or the one place that deviates. Do not patch individual screens with magic numbers.
3. Check both themes and all three accents. Check a narrow window (780px wide) and a long note title.
4. Check keyboard: Tab order, visible focus ring, Esc closes the top-most overlay.
5. Run `python3 tools/lint_qml.py` (brackets, tokens, icon names, component properties, CMake list). It must print 0 errors.
6. New `.qml` file? Add it to `CMakeLists.txt` (the lint tells you if you forget).
7. Keep behaviour in C++ (`vault.cpp`) and presentation in QML. Do not add logic to QML that belongs in the vault.

### Pre-merge checklist
- [ ] Only tokens, no literals
- [ ] Heights are 24 / 32 / 40; radii follow section 2
- [ ] Nested corners concentric
- [ ] Icons 16px, meaning unique
- [ ] Hover weaker than selected; one hover layer; no press-scale
- [ ] No new toast for routine events; empty states use `EmptyState`
- [ ] Contrast OK in light and dark
- [ ] `tools/lint_qml.py` clean

## 6b. Anti-patterns this refactor removed (do not reintroduce)

Toast with a fixed 420px text width; a toast per autosave; a "Today" button that built the date in UTC and
duplicated notes; per-row selection bars that formed a dashed rail; hover stronger than selected; two brand
identities; four scattered toolbars; centred nav items; a Shortcuts page that clipped; 10px labels in ALL CAPS;
infinite pulsing dot; 14 different icon sizes; 12 different control heights.

## 7. Known gaps / good next steps (highest value first)

1. **Markdown preview styling.** The preview uses Qt's default Markdown renderer: no styled code blocks, quotes or heading rhythm. Biggest remaining polish win; consider rendering via `QTextDocument` with a stylesheet or a small HTML pipeline from the vault.
2. **Desktop integration.** Add `notes.desktop` + `app.setDesktopFileName(...)` so GNOME shows the logo in the titlebar and dock under Wayland.
3. **Dead backend code in `vault.cpp/h`:** `duplicateCurrent`, `allTags`, `trashCount`, `openByName`, `clearSavedVault` are not used by the UI. (`activity`, `recordSession` and `recordWords` now feed the heatmap.) Wire them up (duplicate note, tags, `[[wiki link]]` click-through in preview) or delete them.
4. **Context menu** on tree rows (rename, delete, duplicate, reveal) and drag-to-move.
5. **Text size and reading width** as Settings options; a "typewriter" focus mode.
6. **Accessibility:** `Accessible.name` on icon-only buttons (use their `tip`), larger hit targets option.
7. Real translucency/vibrancy on the sidebar is not possible in plain Qt Quick; fake it with a flat tint only (already done).

## 8. Layout map

```
Main.qml            window shell, state, shortcuts, overlays
 ├─ Sidebar         brand | search | tree | footer (vault, activity, settings)
 ├─ TopBar          title | new note, new folder | rename, delete | Segmented (Edit Split Preview Graph)
 ├─ SplitView       TextPane (editor) | TextPane (preview)      / Graph.qml
 ├─ StatusBar       words, reading time, saved state
 ├─ OutlinePanel    headings (pushes content; Ctrl+Shift+O)
 ├─ CommandPalette  Ctrl+K            ├─ Settings  Ctrl+,
 ├─ ActivityDialog  heatmap           ├─ Onboarding  first run
 └─ Toast
```

## 9. Activity data (heatmap)

- Stored locally in `QSettings` key `activity`: one entry per day, `{date, words, sessions, minutes}`, at most 366 days. Nothing leaves the device.
- `words`: words added at each save (deleting never subtracts). `sessions`: app launches. `minutes`: the app counts one minute per minute it is open (`m_uptimeTimer` in `vault.cpp`), shown as "time open".
- `vault.activity` returns a rolling 365 days ending today, including empty days. The dialog does all layout (53 weeks, Monday first) in QML.
