#!/usr/bin/env python3
"""Compile the Adwaita symbolic SVGs listed in tools/icons.json into
qml/fonts/NoteXYZIcons.ttf and rewrite the glyph table inside qml/Icon.qml.

    pip install fonttools
    python3 tools/build_icon_font.py

To add an icon: copy its *-symbolic.svg into tools/adwaita-svg/, add one line
to tools/icons.json ("name": "file.svg"), run this script. Never edit the
glyph table in Icon.qml by hand.

Why a font? It tints with one `color`, stays crisp at 16px, and needs no Qt
SVG plugin or shader effects. Adwaita icons sit on a 16x16 grid, so the font
uses 64 units per SVG unit: at pixelSize 16 one SVG unit is exactly one pixel.
"""
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from fontTools.fontBuilder import FontBuilder
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.reverseContourPen import ReverseContourPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.svgLib.path import parse_path

ROOT = Path(__file__).resolve().parent.parent
SVG_DIR = ROOT / "tools" / "adwaita-svg"
FONT_OUT = ROOT / "qml" / "fonts" / "NoteXYZIcons.ttf"
ICON_QML = ROOT / "qml" / "Icon.qml"
FAMILY = "NoteXYZ Icons"

UPM = 1024
SCALE = UPM / 16          # 64 font units per SVG unit
MAIN_BASE = 0xE000
DIM_BASE = 0xE100


# ---------------------------------------------------------------- geometry
def split_contours(rec):
    """RecordingPen.value -> list of contours, each a list of (op, args)."""
    contours, cur = [], []
    for op, args in rec:
        if op == "moveTo":
            if cur:
                contours.append(cur)
            cur = [(op, args)]
        elif op in ("closePath", "endPath"):
            if cur:
                cur.append((op, args))
                contours.append(cur)
                cur = []
        else:
            cur.append((op, args))
    if cur:
        contours.append(cur)
    return contours


def flatten(contour, steps=8):
    pts, last = [], None
    for op, args in contour:
        if op == "moveTo":
            last = args[0]
            pts.append(last)
        elif op == "lineTo":
            last = args[0]
            pts.append(last)
        elif op == "curveTo" and len(args) == 3:
            p0, (p1, p2, p3) = last, args
            for i in range(1, steps + 1):
                t = i / steps
                u = 1 - t
                pts.append((
                    u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0],
                    u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1],
                ))
            last = p3
        elif op == "qCurveTo" and len(args) == 2:
            p0, (p1, p2) = last, args
            for i in range(1, steps + 1):
                t = i / steps
                u = 1 - t
                pts.append((
                    u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0],
                    u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1],
                ))
            last = p2
        elif op in ("curveTo", "qCurveTo"):
            raise ValueError(f"unsupported {op} with {len(args)} points")
    return pts


def area(poly):
    return 0.5 * sum(
        poly[i][0] * poly[(i + 1) % len(poly)][1] - poly[(i + 1) % len(poly)][0] * poly[i][1]
        for i in range(len(poly))
    )


def inside(pt, poly):
    x, y = pt
    hit = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            hit = not hit
        j = i
    return hit


def fully_inside(inner, outer):
    # nudge points toward the inner centroid so shared edges don't count as outside
    cx = sum(p[0] for p in inner) / len(inner)
    cy = sum(p[1] for p in inner) / len(inner)
    return all(inside((p[0] + (cx - p[0]) * 0.02, p[1] + (cy - p[1]) * 0.02), outer) for p in inner)


def normalise_path(contours):
    """Return [(contour, reverse?)] so outers run clockwise and holes counter-clockwise.

    Separate SVG <path> elements are filled independently, but one glyph is
    filled with the nonzero rule as a whole. Forcing a consistent direction per
    nesting depth stops overlapping paths from cancelling each other out."""
    polys = [flatten(c) for c in contours]
    result = []
    for i, c in enumerate(contours):
        depth = sum(1 for j, o in enumerate(polys) if j != i and fully_inside(polys[i], o))
        want_clockwise = depth % 2 == 0
        is_clockwise = area(polys[i]) < 0
        result.append((c, want_clockwise != is_clockwise))
    return result


def replay(contour, pen):
    for op, args in contour:
        getattr(pen, op)(*args)


# ------------------------------------------------------------------- SVG
def read_layers(svg_path):
    """-> (main_paths, dim_paths): lists of path-data strings."""
    root = ET.parse(svg_path).getroot()
    main, dim = [], []
    for el in root.iter():
        if el.tag.split("}")[-1] != "path":
            continue
        opacity = float(el.get("fill-opacity", "1"))
        (dim if opacity < 0.99 else main).append(el.get("d"))
    return main, dim


def build_glyph(path_strings):
    ttpen = TTGlyphPen(None)
    qpen = Cu2QuPen(ttpen, max_err=1.0, reverse_direction=False)
    flip = (SCALE, 0, 0, -SCALE, 0, UPM)          # y down -> y up, 16 -> 1024
    for d in path_strings:
        rec = RecordingPen()
        parse_path(d, TransformPen(rec, flip))
        for contour, reverse in normalise_path(split_contours(rec.value)):
            replay(contour, ReverseContourPen(qpen) if reverse else qpen)
    return ttpen.glyph()


# ------------------------------------------------------------------ main
def main():
    icons = json.loads((ROOT / "tools" / "icons.json").read_text())
    glyph_order = [".notdef", "space"]
    glyphs = {".notdef": TTGlyphPen(None).glyph(), "space": TTGlyphPen(None).glyph()}
    cmap = {0x20: "space"}
    main_map, dim_map = {}, {}

    for i, (name, fname) in enumerate(icons.items()):
        main_paths, dim_paths = read_layers(SVG_DIR / fname)
        gname = f"i_{name}"
        glyph_order.append(gname)
        glyphs[gname] = build_glyph(main_paths)
        cmap[MAIN_BASE + i] = gname
        main_map[name] = MAIN_BASE + i
        if dim_paths:
            dname = f"i_{name}_dim"
            glyph_order.append(dname)
            glyphs[dname] = build_glyph(dim_paths)
            cmap[DIM_BASE + i] = dname
            dim_map[name] = DIM_BASE + i

    fb = FontBuilder(UPM, isTTF=True)
    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics({g: (UPM, 0) for g in glyph_order})
    # ascent + descent == 1 em, so a Text of height == pixelSize has a line box
    # exactly one glyph tall and the icon is centred without any offset maths.
    fb.setupHorizontalHeader(ascent=UPM, descent=0, lineGap=0)
    fb.setupNameTable({"familyName": FAMILY, "styleName": "Regular"})
    fb.setupOS2(sTypoAscender=UPM, sTypoDescender=0, sTypoLineGap=0,
                usWinAscent=UPM, usWinDescent=0, fsType=0)
    fb.setupPost()
    FONT_OUT.parent.mkdir(parents=True, exist_ok=True)
    fb.save(str(FONT_OUT))

    # ---- rewrite the glyph table in Icon.qml
    def table(m):
        return ",\n".join(f'        "{k}": "\\u{v:04x}"' for k, v in m.items())

    block = (
        "    // BEGIN GLYPHS (generated by tools/build_icon_font.py - do not edit)\n"
        "    readonly property var glyphs: ({\n" + table(main_map) + "\n    })\n"
        "    readonly property var dimGlyphs: ({\n" + table(dim_map) + "\n    })\n"
        "    // END GLYPHS"
    )
    src = ICON_QML.read_text()
    new = re.sub(r"    // BEGIN GLYPHS.*?    // END GLYPHS", lambda _: block, src, flags=re.S)
    if new == src and "BEGIN GLYPHS" not in src:
        sys.exit("Icon.qml has no BEGIN/END GLYPHS markers")
    ICON_QML.write_text(new)
    print(f"{len(main_map)} icons, {len(dim_map)} with a dim layer -> {FONT_OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
