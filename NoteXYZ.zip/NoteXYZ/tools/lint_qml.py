#!/usr/bin/env python3
"""Static sanity checks for the QML (no Qt needed). Run before every commit:  python3 tools/lint_qml.py

Catches: unbalanced brackets, unknown AppTheme tokens, unknown icon names, unknown component types,
unknown properties/signals set on our own components, components missing from CMakeLists.txt,
literal radius/height/spacing numbers that should be tokens (warnings)."""
import glob, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
files = sorted(glob.glob("qml/*.qml"))
errors, warns = [], []

def strip(src):
    """remove comments and string contents (keep quotes) so brackets in text don't confuse us"""
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            while i < n and src[i] != "\n": i += 1
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2
        elif c in "\"'":
            q = c; out.append(q); i += 1
            while i < n and src[i] != q:
                i += 2 if src[i] == "\\" else 1
            out.append(q); i += 1
        else:
            out.append(c); i += 1
    return "".join(out)

src = {f: open(f).read() for f in files}
clean = {f: strip(s) for f, s in src.items()}

# ---- 1. brackets
for f, s in clean.items():
    st = []
    pairs = {")": "(", "]": "[", "}": "{"}
    line = 1
    for ch in s:
        if ch == "\n": line += 1
        if ch in "([{": st.append((ch, line))
        elif ch in ")]}":
            if not st or st[-1][0] != pairs[ch]:
                errors.append(f"{f}:{line}: unbalanced '{ch}'"); break
            st.pop()
    else:
        if st: errors.append(f"{f}: unclosed '{st[-1][0]}' opened on line {st[-1][1]}")

# ---- 2. theme tokens
theme = clean["qml/ThemeObject.qml"]
tokens = set(re.findall(r"property\s+\w+\s+(\w+)\s*:", theme)) | set(re.findall(r"function\s+(\w+)\(", theme))
tokens |= {"dark"}
for f, s in clean.items():
    for m in re.finditer(r"AppTheme\.(\w+)", s):
        if m.group(1) not in tokens:
            errors.append(f"{f}: unknown token AppTheme.{m.group(1)}")

# ---- 3. icon names
icon_src = src["qml/Icon.qml"]
glyphs = set(re.findall(r'"(\w+)": "\\u', icon_src))
for f, s in src.items():
    if f.endswith("Icon.qml"): continue
    for m in re.finditer(r'(?:\bkind|\biconKind|\bicon|\bleadingIcon)\s*:\s*"(\w+)"', s):
        if m.group(1) not in glyphs: errors.append(f"{f}: unknown icon '{m.group(1)}'")
    for m in re.finditer(r'\bicon:\s*"(\w+)"', s):
        if m.group(1) not in glyphs: errors.append(f"{f}: unknown icon '{m.group(1)}'")
    # ternaries like kind: cond ? "a" : "b"
    for m in re.finditer(r'(?:\bkind|\biconKind|\bicon)\s*:\s*([^\n]*\?[^\n]*)', s):
        for name in re.findall(r'"(\w+)"', m.group(1)):
            if name not in glyphs: errors.append(f"{f}: unknown icon '{name}' (ternary)")

# ---- 4. component types
mine = {os.path.basename(f)[:-4] for f in files}
qt_types = set("""Item Rectangle Text Image Row Column Repeater ListView Canvas MouseArea WheelHandler Timer Connections
Behavior NumberAnimation Translate Flickable Shortcut ApplicationWindow Dialog Popup ToolTip Button CheckBox TextField TextArea
ScrollView ScrollBar SplitView RowLayout ColumnLayout StackLayout FolderDialog QtObject Flow Grid Loader Component SequentialAnimation
ParallelAnimation MultiEffect PropertyAnimation PauseAnimation State Transition AnimatedImage Control FocusScope Gradient GradientStop
DropArea Drag Menu MenuItem MenuSeparator""".split())
for f, s in clean.items():
    for m in re.finditer(r"(?<![.\w])([A-Z]\w*)\s*\{", s):
        t = m.group(1)
        if t not in mine and t not in qt_types and not re.search(r"component\s+" + t, s):
            errors.append(f"{f}: unknown type {t}")

# ---- 5. custom components: properties/signals/handlers set on them must exist
std = set("""id anchors Layout SplitView Keys ScrollBar width height implicitWidth implicitHeight x y z visible opacity enabled clip
color radius text font spacing padding leftPadding rightPadding topPadding bottomPadding border parent scale rotation transform
focus objectName model delegate handle orientation currentIndex placeholderText checked default required readonly property signal
function component Component Tip Elevation Behavior Timer Connections Shortcut onClicked onToggled onAccepted onRejected onOpened
onTextChanged onClosed onVisibleChanged onOpenChanged onActivated onTriggered onPressed onEntered onExited onClosing onStatusChanged onClosed
onWidthChanged onHeightChanged onDarkChanged onAccentChanged onNoteClicked onCloseRequested target sequence interval title
wrapMode elide horizontalAlignment verticalAlignment textFormat selectByMouse readOnly modal closePolicy header footer background
contentItem indicator hoverEnabled cursorShape boundsBehavior from to duration easing property sourceSize source fillMode smooth mipmap
styleColor style renderType minimumWidth minimumHeight currentFolder selectedFolder onFinished""".split())
def decls(s):
    d = set(re.findall(r"property\s+(?:alias\s+)?\w+\s+(\w+)", s)) | set(re.findall(r"property\s+alias\s+(\w+)", s))
    d |= set(re.findall(r"signal\s+(\w+)", s))
    d |= {"on" + n[0].upper() + n[1:] for n in re.findall(r"signal\s+(\w+)", s)}
    d |= {"on" + n[0].upper() + n[1:] + "Changed" for n in re.findall(r"property\s+(?:alias\s+)?\w+\s+(\w+)", s)}
    return d
comp_decl = {os.path.basename(f)[:-4]: decls(clean[f]) | {"onVisibleChanged"} for f in files}
# base type of each component decides which std keys are fair game
for f, s in clean.items():
    for m in re.finditer(r"(?<![.\w])([A-Z]\w*)\s*\{", s):
        t = m.group(1)
        if t not in comp_decl or t == os.path.basename(f)[:-4]: continue
        i, depth, line = m.end(), 1, 0
        keys = []
        # walk the block, recording keys at depth 1
        j = i
        while j < len(s) and depth:
            ch = s[j]
            if ch == "{": depth += 1
            elif ch == "}": depth -= 1
            elif depth == 1:
                km = re.match(r"\s*([A-Za-z_][\w.]*)\s*:", s[j:j + 80]) if (j == i or s[j - 1] in "\n;{") else None
                if km: keys.append(km.group(1))
            j += 1
        for k in keys:
            root = k.split(".")[0]
            if root in std or k in comp_decl[t] or root in comp_decl[t]: continue
            if re.match(r"on[A-Z]", root): 
                # builtin handler of the base item? allow standard *Changed handlers
                if root.endswith("Changed"): continue
            errors.append(f"{f}: {t} has no property/signal '{k}'")

# ---- 6. CMake lists every component
cm = open("CMakeLists.txt").read()
for f in files:
    if f.endswith("ThemeObject.qml"): continue
    if f not in cm: errors.append(f"CMakeLists.txt: missing {f}")

# ---- 7. warnings: literal sizes that should be tokens
for f, s in clean.items():
    if f.endswith("ThemeObject.qml"): continue
    for m in re.finditer(r"\bradius:\s*(\d+)\b", s):
        if m.group(1) not in ("0", "3"): warns.append(f"{f}: literal radius {m.group(1)}")
    for m in re.finditer(r"\bpixelSize:\s*(\d+)\b", s):
        warns.append(f"{f}: literal font size {m.group(1)}")

for w in warns: print("warn ", w)
for e in errors: print("ERROR", e)
print(f"\n{len(files)} files, {len(errors)} errors, {len(warns)} warnings")
sys.exit(1 if errors else 0)
