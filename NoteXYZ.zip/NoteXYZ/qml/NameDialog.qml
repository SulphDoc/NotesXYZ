import QtQuick
import QtQuick.Layouts

// Asks for a name: new note, new folder, or rename. Open with openFor("note" | "folder" | "rename").
AppDialog {
    id: dlg
    property string what: "note"
    readonly property var titles: ({ note: "New note", folder: "New folder", rename: "Rename note" })

    function openFor(kind) { what = kind; open() }

    onOpened: {
        field.text = what === "rename" ? vault.currentName.replace(/\.md$/i, "") : ""
        field.forceActiveFocus()
        field.selectAll()
    }
    onAccepted: {
        const name = field.text.trim()
        if (name === "") return
        if (what === "note") vault.newNote(name)
        else if (what === "folder") vault.newFolder(name)
        else vault.renameCurrent(name)
    }

    contentItem: ColumnLayout {
        spacing: AppTheme.space4

        Text {
            text: dlg.titles[dlg.what]
            color: AppTheme.fg
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontXl
            font.weight: Font.DemiBold
        }
        AppField {
            id: field
            Layout.fillWidth: true
            placeholderText: dlg.what === "folder" ? "Folder name" : "Note name"
            onAccepted: dlg.accept()
        }
        RowLayout {
            Layout.alignment: Qt.AlignRight
            spacing: AppTheme.space2
            ToolBtn { text: "Cancel"; onClicked: dlg.reject() }
            ToolBtn { text: dlg.what === "rename" ? "Rename" : "Create"; primary: true; enabled: field.text.trim() !== ""; onClicked: dlg.accept() }
        }
    }
}
