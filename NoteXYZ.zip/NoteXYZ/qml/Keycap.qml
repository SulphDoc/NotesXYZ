import QtQuick

// A keyboard shortcut chip, e.g. Keycap { text: "Ctrl+N" }
Rectangle {
    property alias text: label.text
    implicitWidth: label.implicitWidth + AppTheme.space3 * 2
    implicitHeight: AppTheme.ctrlSm - 2
    radius: AppTheme.radiusSm
    color: AppTheme.trough
    border.width: 1
    border.color: AppTheme.line

    Text {
        id: label
        anchors.centerIn: parent
        color: AppTheme.muted
        font.family: AppTheme.mono
        font.pixelSize: AppTheme.fontXs
    }
}
