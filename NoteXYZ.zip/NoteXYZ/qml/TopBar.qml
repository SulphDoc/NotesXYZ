import QtQuick
import QtQuick.Layouts

// Header bar: title on the left; create, note actions and the view switcher on the right.
Rectangle {
    id: root
    property string title: ""
    property string folder: ""
    property bool hasNote: false
    property bool sidebarHidden: false
    property int viewIndex: 0

    signal showSidebar()
    signal newNoteRequested()
    signal newFolderRequested()
    signal renameRequested()
    signal deleteRequested()
    signal saveRequested()
    signal viewPicked(int index)

    implicitHeight: AppTheme.barH
    color: AppTheme.bg

    Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom } height: 1; color: AppTheme.line }

    RowLayout {
        anchors { fill: parent; leftMargin: AppTheme.gutter; rightMargin: AppTheme.gutter }
        spacing: AppTheme.space2

        ToolBtn {
            visible: root.sidebarHidden
            iconOnly: true
            iconKind: "sidebar"
            tip: "Show sidebar (Ctrl+B)"
            onClicked: root.showSidebar()
        }
        Text {
            visible: root.folder !== ""
            text: root.folder + " /"
            color: AppTheme.faint
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontMd
        }
        Text {
            Layout.fillWidth: true
            elide: Text.ElideRight
            text: root.title
            color: AppTheme.fg
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontXl
            font.weight: Font.DemiBold
        }

        ToolBtn { iconOnly: true; iconKind: "document_new"; tip: "New note (Ctrl+N)"; onClicked: root.newNoteRequested() }
        ToolBtn { iconOnly: true; iconKind: "folder_new"; tip: "New folder (Ctrl+Shift+N)"; onClicked: root.newFolderRequested() }
        Rectangle { visible: root.hasNote; Layout.preferredWidth: 1; Layout.preferredHeight: AppTheme.space4; color: AppTheme.line }

        ToolBtn { visible: root.hasNote && !vault.autosave; iconOnly: true; iconKind: "save"; tip: "Save (Ctrl+S)"; onClicked: root.saveRequested() }
        ToolBtn { visible: root.hasNote; iconOnly: true; iconKind: "edit"; tip: "Rename"; onClicked: root.renameRequested() }
        ToolBtn { visible: root.hasNote; iconOnly: true; iconKind: "trash"; tip: "Delete"; danger: true; onClicked: root.deleteRequested() }

        Rectangle { Layout.preferredWidth: 1; Layout.preferredHeight: AppTheme.space4; color: AppTheme.line }

        Segmented {
            current: root.viewIndex
            model: [
                { icon: "edit",    tip: "Edit (Ctrl+1)" },
                { icon: "split",   tip: "Split (Ctrl+2)" },
                { icon: "preview", tip: "Preview (Ctrl+3)" },
                { icon: "graph",   tip: "Graph (Ctrl+G)" }
            ]
            onPicked: (i) => root.viewPicked(i)
        }
    }
}
