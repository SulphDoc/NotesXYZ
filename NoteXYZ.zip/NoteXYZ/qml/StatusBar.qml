import QtQuick
import QtQuick.Layouts

// Information only: word count, reading time, save state. No buttons live here.
Rectangle {
    id: root
    readonly property int words: {
        const t = vault.text.trim()
        return t === "" ? 0 : t.split(/\s+/).length
    }
    readonly property int minutes: Math.ceil(words / 200)
    readonly property bool hasNote: vault.currentPath !== ""

    implicitHeight: AppTheme.statusH
    color: AppTheme.bg

    Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: AppTheme.line }

    RowLayout {
        anchors { fill: parent; leftMargin: AppTheme.gutter; rightMargin: AppTheme.gutter }
        spacing: AppTheme.space3

        Text {
            visible: root.hasNote
            text: root.words + (root.words === 1 ? " word" : " words")
                  + (root.words > 0 ? "  ·  " + root.minutes + " min read" : "")
            color: AppTheme.faint
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontSm
        }
        Item { Layout.fillWidth: true }
        Text {
            visible: root.hasNote
            text: vault.dirty ? "Unsaved changes" : "Saved"
            color: vault.dirty ? AppTheme.warning : AppTheme.faint
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontSm
        }
    }
}
