import QtQuick
import QtQuick.Effects

// Soft drop shadow for a card. Declare it as a child of the card:  Elevation { radius: AppTheme.radiusLg }
// A real blurred shadow (MultiEffect, Qt 6.5+), drawn behind the parent because z is negative.
Item {
    id: root
    property real radius: AppTheme.radiusLg
    property real lift: 1          // 1 = dialog, 0.6 = toast or popover

    z: -1
    anchors.fill: parent

    // The shape that casts the shadow. Inset by 1px so no dark fringe shows around the card's antialiased edge.
    Rectangle {
        id: caster
        anchors.fill: parent
        anchors.margins: 1
        radius: Math.max(0, root.radius - 1)
        color: "black"
        visible: false
    }
    MultiEffect {
        anchors.fill: caster
        source: caster
        autoPaddingEnabled: true
        blurMax: 48
        shadowEnabled: true
        shadowColor: "black"
        shadowBlur: 0.55 + 0.45 * root.lift
        shadowOpacity: (AppTheme.dark ? 0.6 : 0.2) * root.lift
        shadowHorizontalOffset: 0
        shadowVerticalOffset: Math.round(10 * root.lift)
    }
}
