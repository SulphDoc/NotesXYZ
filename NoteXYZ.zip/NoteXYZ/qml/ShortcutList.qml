import QtQuick
import QtQuick.Layouts

// The single list of keyboard shortcuts (shown in Settings > Shortcuts). Keep in sync with Main.qml.
Column {
    id: root
    readonly property var rows: [
        ["Ctrl+K", "Command palette"],
        ["Ctrl+N", "New note"],
        ["Ctrl+Shift+N", "New folder"],
        ["Ctrl+O", "Open vault"],
        ["Ctrl+S", "Save"],
        ["Ctrl+F", "Search notes"],
        ["Ctrl+1 / 2 / 3", "Edit / Split / Preview"],
        ["Ctrl+G", "Graph"],
        ["Ctrl+B", "Toggle sidebar"],
        ["Ctrl+Shift+O", "Outline"],
        ["Ctrl+Shift+D", "Toggle dark mode"],
        ["Ctrl+R", "Refresh vault"],
        ["Ctrl+Z", "Undo delete (outside the editor)"],
        ["Ctrl+ +  /  Ctrl+ -", "Text size"],
        ["Ctrl+,", "Settings"],
        ["?", "This list"],
        ["Esc", "Close overlay"]
    ]
    spacing: AppTheme.space1

    Repeater {
        model: root.rows
        delegate: RowLayout {
            required property var modelData
            width: root.width
            spacing: AppTheme.space3
            Item {
                Layout.preferredWidth: 150
                Layout.preferredHeight: AppTheme.ctrlSm
                Keycap { anchors.verticalCenter: parent.verticalCenter; text: modelData[0] }
            }
            Text {
                Layout.fillWidth: true
                text: modelData[1]
                color: AppTheme.muted
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontMd
            }
        }
    }
}
