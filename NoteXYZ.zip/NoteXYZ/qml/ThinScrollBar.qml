import QtQuick
import QtQuick.Controls

// Overlay scrollbar that fades out when idle (macOS style).
// Usage:  ScrollBar.vertical: ThinScrollBar {}
ScrollBar {
    id: bar
    padding: AppTheme.space0
    contentItem: Rectangle {
        implicitWidth: 6
        implicitHeight: 24
        radius: width / 2
        color: AppTheme.faint
        opacity: bar.pressed ? 0.8 : (bar.active ? 0.5 : 0)
        Behavior on opacity { NumberAnimation { duration: AppTheme.motionSlow } }
    }
}
