import QtQuick
import QtQuick.Layouts

// Shown until a vault is open.
Rectangle {
    id: root
    signal openVaultRequested()
    color: AppTheme.bg

    ColumnLayout {
        anchors.centerIn: parent
        width: Math.min(360, parent.width - AppTheme.space6 * 2)
        spacing: AppTheme.space2

        Logo { Layout.alignment: Qt.AlignHCenter; size: 96 }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: "NoteXYZ"
            color: AppTheme.fg
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontDisplay
            font.weight: Font.Bold
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: "Plain Markdown notes in a folder you own."
            color: AppTheme.muted
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontLg
        }
        ToolBtn {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: AppTheme.space4
            implicitHeight: AppTheme.ctrlLg
            text: "Open a folder"
            iconKind: "folder_open"
            primary: true
            onClicked: root.openVaultRequested()
        }

        SectionLabel {
            visible: vault.recentVaults.length > 0
            Layout.topMargin: AppTheme.space5
            text: "Recent"
        }
        Repeater {
            model: vault.recentVaults.slice(0, 3)
            delegate: ToolBtn {
                required property string modelData
                Layout.fillWidth: true
                alignLeft: true
                iconKind: "folder"
                text: modelData.split("/").pop()
                tip: modelData
                onClicked: vault.openVault("file://" + modelData)
            }
        }
    }
}
