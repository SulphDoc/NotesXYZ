import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Heading outline of the open note. Sits beside the editor (it pushes content, it does not cover it).
Rectangle {
    id: root
    signal headingClicked(int charIndex)
    signal closeRequested()

    readonly property var headings: visible ? parseHeadings(vault.text) : []

    function parseHeadings(text) {
        const out = []
        let pos = 0
        let inCode = false
        for (const line of text.split("\n")) {
            if (/^\s*```/.test(line)) inCode = !inCode
            const m = inCode ? null : /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(line)
            if (m) out.push({ level: m[1].length, title: m[2], index: pos })
            pos += line.length + 1
        }
        return out
    }

    color: AppTheme.panel
    Rectangle { anchors { top: parent.top; bottom: parent.bottom; left: parent.left } width: 1; color: AppTheme.line }

    ColumnLayout {
        anchors { fill: parent; leftMargin: 1 }
        spacing: 0

        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: AppTheme.barH
            Layout.leftMargin: AppTheme.gutter
            Layout.rightMargin: AppTheme.space2
            Text {
                Layout.fillWidth: true
                text: "Outline"
                color: AppTheme.fg
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontLg
                font.weight: Font.DemiBold
            }
            ToolBtn { iconOnly: true; iconKind: "close"; tip: "Close (Esc)"; onClicked: root.closeRequested() }
        }
        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: AppTheme.line }

        ListView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: AppTheme.space2
            clip: true
            spacing: AppTheme.space0
            model: root.headings
            ScrollBar.vertical: ThinScrollBar {}

            delegate: Rectangle {
                id: item
                required property var modelData
                width: ListView.view.width
                height: AppTheme.ctrlMd
                radius: AppTheme.radiusMd
                color: ma.containsMouse ? AppTheme.hover : "transparent"
                Text {
                    anchors { fill: parent; leftMargin: AppTheme.space2 + (item.modelData.level - 1) * AppTheme.space3; rightMargin: AppTheme.space2 }
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    text: item.modelData.title
                    color: item.modelData.level === 1 ? AppTheme.fg : AppTheme.muted
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontMd
                    font.weight: item.modelData.level === 1 ? Font.DemiBold : Font.Normal
                }
                MouseArea {
                    id: ma
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.headingClicked(item.modelData.index)
                }
            }

            EmptyState {
                anchors.centerIn: parent
                visible: root.headings.length === 0
                icon: "list"
                title: "No headings"
                hint: "Start a line with # to add one"
            }
        }
    }
}
