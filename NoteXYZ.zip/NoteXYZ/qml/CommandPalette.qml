import QtQuick
import QtQuick.Controls

// Ctrl+K: one field for actions and notes. A launcher, not a dialog: it appears instantly (no animation).
Rectangle {
    id: root
    property bool open: false
    property int current: 0
    property var entries: []

    signal noteSelected(string path)
    signal actionSelected(string id)
    signal closeRequested()

    readonly property int rowH: AppTheme.ctrlLg + AppTheme.space1
    readonly property int listH: Math.max(120, Math.min(entries.length, 8) * rowH + AppTheme.space1 * 2)

    function rebuild() {
        const q = field.text.trim().toLowerCase()
        const cmds = [
            { id: "new",       name: "New note",             detail: "Create a note",                   icon: "document_new" },
            { id: "today",     name: "Today’s note",         detail: "Open or create today’s note",     icon: "calendar" },
            { id: "activity",  name: "Activity",             detail: "Words written and time open, last year", icon: "calendar" },
            { id: "folder",    name: "New folder",           detail: "Create a folder",                 icon: "folder_new" },
            { id: "open",      name: "Open vault…",          detail: "Choose another folder of notes",  icon: "folder_open" },
            { id: "edit",      name: "Edit",                 detail: "Plain text editing",              icon: "edit" },
            { id: "split",     name: "Split view",           detail: "Editor and preview side by side", icon: "split" },
            { id: "preview",   name: "Preview",              detail: "Render Markdown",                 icon: "preview" },
            { id: "graph",     name: "Graph",                detail: "See how notes link together",     icon: "graph" },
            { id: "sidebar",   name: "Toggle sidebar",       detail: "Show or hide the note list",      icon: "sidebar" },
            { id: "outline",   name: "Toggle outline",       detail: "Headings of the open note",       icon: "list" },
            { id: "export",    name: "Export as HTML",       detail: "Write a .html file beside the note", icon: "external" },
            { id: "undo",      name: "Undo delete",          detail: "Restore the last deleted note",   icon: "back" },
            { id: "theme",     name: "Toggle dark mode",     detail: "Switch between light and dark",   icon: "moon" },
            { id: "accent",    name: "Change accent",        detail: "Cycle teal / blue / coral",       icon: "palette" },
            { id: "refresh",   name: "Refresh vault",        detail: "Rescan the folder",               icon: "refresh" },
            { id: "settings",  name: "Settings",             detail: "Open settings",                   icon: "settings" },
            { id: "shortcuts", name: "Keyboard shortcuts",   detail: "See every shortcut",              icon: "keyboard" }
        ]
        const list = []
        for (const c of cmds)
            if (!q || c.name.toLowerCase().indexOf(q) >= 0) { c.type = "action"; list.push(c) }
        if (q)
            for (const n of vault.search(field.text))
                list.push({ type: "note", name: n.name, detail: n.snippet, path: n.path, icon: "document" })
        entries = list
        current = list.length ? 0 : -1
    }

    function activate(e) {
        if (!e) return
        if (e.type === "note") noteSelected(e.path)
        else actionSelected(e.id)
        root.open = false
    }

    visible: open
    width: Math.min(620, parent.width - AppTheme.space6 * 2)
    height: AppTheme.barH + 1 + listH + 1 + AppTheme.ctrlMd
    x: Math.round((parent.width - width) / 2)
    y: Math.round(parent.height * 0.14)
    color: AppTheme.surface
    radius: AppTheme.radiusLg
    border.width: 1
    border.color: AppTheme.borderStrong
    Elevation { radius: root.radius }

    onOpenChanged: if (open) { field.text = ""; rebuild(); Qt.callLater(() => field.forceActiveFocus()) }

    MouseArea { anchors.fill: parent }     // swallow clicks so the scrim doesn't close the palette

    // ---- input
    Item {
        id: inputRow
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: AppTheme.barH
        Icon {
            id: lens
            anchors { left: parent.left; leftMargin: AppTheme.gutter; verticalCenter: parent.verticalCenter }
            kind: "search"
            col: AppTheme.faint
        }
        TextField {
            id: field
            anchors { left: lens.right; leftMargin: AppTheme.space2; right: parent.right; rightMargin: AppTheme.gutter; verticalCenter: parent.verticalCenter }
            placeholderText: "Search notes or run a command"
            placeholderTextColor: AppTheme.faint
            color: AppTheme.fg
            selectionColor: AppTheme.accentFill
            selectedTextColor: AppTheme.accentOn
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontXl
            leftPadding: 0
            background: null
            onTextChanged: root.rebuild()
            Keys.onDownPressed: if (root.current < root.entries.length - 1) root.current++
            Keys.onUpPressed: if (root.current > 0) root.current--
            Keys.onReturnPressed: root.activate(root.entries[root.current])
            Keys.onEnterPressed: root.activate(root.entries[root.current])
            Keys.onEscapePressed: root.closeRequested()
        }
    }
    Rectangle { id: sepTop; anchors { top: inputRow.bottom; left: parent.left; right: parent.right } height: 1; color: AppTheme.line }

    // ---- results
    ListView {
        id: list
        anchors { top: sepTop.bottom; left: parent.left; right: parent.right; margins: AppTheme.space1 }
        height: root.listH - AppTheme.space1 * 2
        clip: true
        model: root.entries
        currentIndex: root.current
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ThinScrollBar {}

        delegate: Rectangle {
            id: row
            required property var modelData
            required property int index
            readonly property bool isOn: index === root.current
            width: ListView.view.width
            height: root.rowH
            radius: AppTheme.inner(AppTheme.radiusLg, AppTheme.space1)      // concentric with the palette
            color: isOn ? AppTheme.accentSoft : "transparent"

            Row {
                anchors { fill: parent; leftMargin: AppTheme.space3; rightMargin: AppTheme.space3 }
                spacing: AppTheme.space3
                Icon {
                    anchors.verticalCenter: parent.verticalCenter
                    kind: row.modelData.icon
                    col: row.isOn ? AppTheme.accent : AppTheme.muted
                }
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 16 - AppTheme.space3
                    Text {
                        width: parent.width
                        elide: Text.ElideRight
                        text: row.modelData.name
                        color: AppTheme.fg
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontMd
                        font.weight: Font.Medium
                    }
                    Text {
                        width: parent.width
                        elide: Text.ElideRight
                        text: row.modelData.detail
                        color: AppTheme.faint
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontXs
                    }
                }
            }
            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                onEntered: root.current = row.index
                onClicked: root.activate(row.modelData)
            }
        }

        EmptyState {
            anchors.centerIn: parent
            visible: root.entries.length === 0
            icon: "search"
            title: "No matches"
        }
    }

    // ---- hint footer
    Rectangle { id: sepBottom; anchors { bottom: hint.top; left: parent.left; right: parent.right } height: 1; color: AppTheme.line }
    Text {
        id: hint
        anchors { bottom: parent.bottom; left: parent.left; right: parent.right }
        height: AppTheme.ctrlMd
        leftPadding: AppTheme.gutter
        verticalAlignment: Text.AlignVCenter
        text: "↑ ↓ to move   ·   Enter to run   ·   Esc to close"
        color: AppTheme.faint
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontXs
    }
}
