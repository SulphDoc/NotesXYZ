import QtQuick
import QtQuick.Layouts

// Confirms deleting the open note. The note goes to the vault trash and can be restored with Ctrl+Z.
AppDialog {
    id: dlg
    onAccepted: vault.deleteCurrent()

    contentItem: ColumnLayout {
        spacing: AppTheme.space4

        Text {
            text: "Delete this note?"
            color: AppTheme.fg
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontXl
            font.weight: Font.DemiBold
        }
        Text {
            Layout.fillWidth: true
            wrapMode: Text.Wrap
            text: "“" + vault.currentName + "” moves to the trash. You can undo this right after."
            color: AppTheme.muted
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontMd
        }
        RowLayout {
            Layout.alignment: Qt.AlignRight
            spacing: AppTheme.space2
            ToolBtn { text: "Cancel"; onClicked: dlg.reject() }
            ToolBtn { text: "Delete"; danger: true; onClicked: dlg.accept() }
        }
    }
}
