import QtQuick

// Icon segmented control with a sliding thumb.
// Concentric corners: track radius 8, thumb radius 6 (inset 2).
//   Segmented { model: [{ icon: "edit", tip: "Edit" }, ...]; current: 0; onPicked: (i) => ... }
Rectangle {
    id: root
    property var model: []
    property int current: 0
    signal picked(int index)

    readonly property int segW: 36
    readonly property int inset: AppTheme.space0

    implicitWidth: model.length * segW + inset * 2
    implicitHeight: AppTheme.ctrlMd
    radius: AppTheme.radiusMd
    color: AppTheme.trough

    Rectangle {
        x: root.inset + root.current * root.segW
        y: root.inset
        width: root.segW
        height: root.height - root.inset * 2
        radius: AppTheme.inner(root.radius, root.inset)
        color: AppTheme.thumb
        border.width: 1
        border.color: AppTheme.line
        Behavior on x { NumberAnimation { duration: AppTheme.motionFast; easing.type: Easing.OutCubic } }
    }

    Repeater {
        model: root.model
        delegate: Item {
            id: seg
            required property var modelData
            required property int index
            readonly property bool isOn: index === root.current
            x: root.inset + index * root.segW
            y: root.inset
            width: root.segW
            height: root.height - root.inset * 2

            Icon {
                anchors.centerIn: parent
                kind: seg.modelData.icon
                col: seg.isOn ? AppTheme.fg : AppTheme.muted
            }
            MouseArea {
                id: ma
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.picked(seg.index)
            }
            Tip { parent: seg; text: seg.modelData.tip; show: ma.containsMouse }
        }
    }
}
