import QtQuick
import QtQuick.Layouts

// First-run walkthrough: welcome, choose a folder, done.
Item {
    id: root
    property bool open: false
    property int step: 0
    readonly property int steps: 3
    readonly property string folderName: vault.root !== "" ? vault.root.split("/").pop() : ""

    signal openVaultRequested()
    signal finished()

    anchors.fill: parent
    visible: open
    onOpenChanged: if (open) step = 0

    Scrim {}

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(520, parent.width - AppTheme.space6 * 2)
        height: 340
        color: AppTheme.surface
        radius: AppTheme.radiusLg
        border.width: 1
        border.color: AppTheme.borderStrong
        Elevation { radius: card.radius }
        MouseArea { anchors.fill: parent }

        StackLayout {
            anchors { fill: parent; margins: AppTheme.dialogPad; bottomMargin: AppTheme.dialogPad + AppTheme.ctrlMd + AppTheme.space5 }
            currentIndex: root.step

            // 0: welcome
            ColumnLayout {
                spacing: AppTheme.space2
                Logo { size: 64 }
                Text {
                    text: "Welcome to NoteXYZ"
                    color: AppTheme.fg
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXxl
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    text: "Your notes are plain Markdown files in a folder. No account, no lock-in, and every other app can read them."
                    color: AppTheme.muted
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontLg
                }
                Item { Layout.fillHeight: true }
            }

            // 1: choose a folder
            ColumnLayout {
                spacing: AppTheme.space3
                Text {
                    text: "Choose your notes folder"
                    color: AppTheme.fg
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXxl
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    text: "Pick an existing folder of notes or create an empty one."
                    color: AppTheme.muted
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontLg
                }
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: AppTheme.ctrlLg
                    radius: AppTheme.radiusMd
                    color: AppTheme.trough
                    RowLayout {
                        anchors { fill: parent; leftMargin: AppTheme.space3; rightMargin: AppTheme.space3 }
                        spacing: AppTheme.space2
                        Icon { kind: "folder"; col: AppTheme.muted }
                        Text {
                            Layout.fillWidth: true
                            elide: Text.ElideMiddle
                            text: vault.root !== "" ? vault.root : "No folder chosen yet"
                            color: vault.root !== "" ? AppTheme.fg : AppTheme.faint
                            font.family: AppTheme.ui
                            font.pixelSize: AppTheme.fontMd
                        }
                    }
                }
                RowLayout {
                    spacing: AppTheme.space4
                    ToolBtn { text: vault.root !== "" ? "Change folder" : "Choose folder"; iconKind: "folder_open"; onClicked: root.openVaultRequested() }
                    AppCheckBox { text: "Remember this folder"; checked: vault.rememberFolder; onToggled: vault.rememberFolder = checked }
                }
                Item { Layout.fillHeight: true }
            }

            // 2: done
            ColumnLayout {
                spacing: AppTheme.space2
                Icon { kind: "check"; size: 32; col: AppTheme.accent }
                Text {
                    Layout.topMargin: AppTheme.space2
                    text: "You’re all set"
                    color: AppTheme.fg
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXxl
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    text: "Your notes live in “" + root.folderName + "”. Press Ctrl+K any time to search or run a command."
                    color: AppTheme.muted
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontLg
                }
                Item { Layout.fillHeight: true }
            }
        }

        // ---- footer: progress dots + buttons
        RowLayout {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: AppTheme.dialogPad }
            spacing: AppTheme.space2

            Row {
                spacing: AppTheme.space1 + AppTheme.space0
                Repeater {
                    model: root.steps
                    Rectangle {
                        required property int index
                        width: index === root.step ? 16 : 6
                        height: 6
                        radius: 3
                        color: index === root.step ? AppTheme.accent : AppTheme.borderStrong
                        Behavior on width { NumberAnimation { duration: AppTheme.motionFast } }
                    }
                }
            }
            Item { Layout.fillWidth: true }
            ToolBtn { visible: root.step > 0; text: "Back"; onClicked: root.step-- }
            ToolBtn {
                text: root.step === root.steps - 1 ? "Start writing" : "Continue"
                primary: true
                enabled: root.step !== 1 || vault.root !== ""
                onClicked: root.step === root.steps - 1 ? root.finished() : root.step++
            }
        }
    }
}
