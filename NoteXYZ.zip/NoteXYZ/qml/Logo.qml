import QtQuick

// The app mark — the geometric emblem supplied as mark-*.svg.
// Colour variant on dark surfaces, black variant on light surfaces.
Image {
    property real size: 32
    width: size
    height: size
    source: AppTheme.dark ? "images/logo-color.png" : "images/logo-black.png"
    sourceSize.width: size * 2
    sourceSize.height: size * 2
    fillMode: Image.PreserveAspectFit
    smooth: true
}
