import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Source-list sidebar: brand, search, the note tree, and a footer (vault, activity, settings).
Rectangle {
    id: root
    signal openVault()
    signal openActivity()
    signal openSettings()
    signal noteOpened()
    signal renameRequested()
    signal duplicateRequested()
    signal deleteRequested()
    signal revealRequested()

    function focusSearch() { search.forceActiveFocus(); search.selectAll() }
    function clearSearch() { search.clear() }

    color: AppTheme.panel

    Rectangle { anchors { top: parent.top; bottom: parent.bottom; right: parent.right } width: 1; color: AppTheme.line }

    ColumnLayout {
        anchors { fill: parent; rightMargin: 1 }
        spacing: 0

        // ---- brand row
        RowLayout {
            Layout.fillWidth: true
            Layout.margins: AppTheme.gutter
            Layout.bottomMargin: AppTheme.space2
            spacing: AppTheme.space2
            Logo { size: 24 }
            Text {
                Layout.fillWidth: true
                text: "NoteXYZ"
                color: AppTheme.fg
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontLg
                font.weight: Font.DemiBold
            }
        }

        // ---- search
        AppField {
            id: search
            Layout.fillWidth: true
            Layout.leftMargin: AppTheme.gutter
            Layout.rightMargin: AppTheme.gutter
            Layout.bottomMargin: AppTheme.space2
            placeholderText: "Search"
            leadingIcon: "search"
            clearable: true
            text: vault.filter
            onTextChanged: if (vault.filter !== text) vault.filter = text
            Keys.onDownPressed: { files.forceActiveFocus(); files.currentIndex = 0 }
            Keys.onEscapePressed: { search.clear(); files.forceActiveFocus() }
        }

        // ---- tags
        Flow {
            Layout.fillWidth: true
            Layout.leftMargin: AppTheme.gutter
            Layout.rightMargin: AppTheme.gutter
            Layout.bottomMargin: AppTheme.space2
            spacing: AppTheme.space1
            visible: vault.tags.length > 0 && search.text === ""
            Repeater {
                model: vault.tags
                delegate: ToolBtn {
                    text: modelData
                    onClicked: { vault.filter = modelData; root.noteOpened() }
                }
            }
        }

        // ---- tree
        ListView {
            id: files
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.leftMargin: AppTheme.space2
            Layout.rightMargin: AppTheme.space2
            clip: true
            spacing: AppTheme.space0
            model: vault.tree
            currentIndex: -1
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ThinScrollBar {}

            Keys.onReturnPressed: if (currentItem) currentItem.activate()
            Keys.onEnterPressed: if (currentItem) currentItem.activate()
            Keys.onUpPressed: if (currentIndex > 0) currentIndex--; else search.forceActiveFocus()
            Keys.onDownPressed: if (currentIndex < count - 1) currentIndex++

            delegate: Rectangle {
                id: row
                required property var modelData
                required property int index
                readonly property bool isDir: modelData.dir
                readonly property bool selected: !isDir && modelData.path === vault.currentPath

                function activate() {
                    if (isDir) vault.toggleDir(modelData.path)
                    else { vault.openFile(modelData.path); root.noteOpened() }
                }

                width: ListView.view.width
                height: AppTheme.ctrlMd
                radius: AppTheme.radiusMd
                color: dropMa.containsMouse && row.isDir ? AppTheme.accentSoft
                     : selected ? AppTheme.accentSoft : (ma.containsMouse ? AppTheme.hover : "transparent")
                border.width: files.activeFocus && files.currentIndex === index ? 2 : 0
                border.color: AppTheme.focusRing

                // Notes can be dragged onto a folder row to move them into it.
                Drag.active: !row.isDir && ma.drag.active
                Drag.hotSpot.x: width / 2
                Drag.hotSpot.y: height / 2
                Drag.mimeData: !row.isDir ? { "text/plain": row.modelData.path } : ({})
                Drag.dragType: Drag.Automatic
                Drag.onDragStarted: files.currentIndex = row.index

                DropArea {
                    id: dropMa
                    anchors.fill: parent
                    enabled: row.isDir
                    keys: ["text/plain"]
                    onDropped: (drop) => {
                        if (vault.moveNote(drop.text, row.modelData.path))
                            drop.acceptProposedAction()
                    }
                }

                RowLayout {
                    anchors {
                        fill: parent
                        leftMargin: AppTheme.space2 + row.modelData.depth * AppTheme.space4
                        rightMargin: AppTheme.space2
                    }
                    spacing: AppTheme.space2

                    Icon {
                        opacity: row.isDir ? 1 : 0
                        kind: row.modelData.expanded ? "chevron_down" : "chevron_right"
                        col: AppTheme.faint
                    }
                    Icon {
                        kind: row.isDir ? (row.modelData.expanded ? "folder_open" : "folder") : "document"
                        col: row.selected ? AppTheme.accent : (row.isDir ? AppTheme.muted : AppTheme.faint)
                    }
                    Text {
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        text: row.isDir ? row.modelData.name : row.modelData.name.replace(/\.md$/i, "")
                        color: AppTheme.fg
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontMd
                        font.weight: row.selected ? Font.DemiBold : Font.Normal
                    }
                }
                MouseArea {
                    id: ma
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    cursorShape: Qt.PointingHandCursor
                    drag.target: row.isDir ? null : dragGhost
                    drag.filterChildren: true
                    onClicked: (mouse) => {
                        files.currentIndex = row.index
                        if (mouse.button === Qt.RightButton && !row.isDir) {
                            vault.openFile(row.modelData.path)
                            menu.popup(mouse.x, mouse.y)
                        } else {
                            row.activate()
                        }
                    }
                }
                Item { id: dragGhost; width: 1; height: 1; visible: false }

                Menu {
                    id: menu
                    MenuItem { text: "Rename"; onTriggered: root.renameRequested() }
                    MenuItem { text: "Duplicate"; onTriggered: root.duplicateRequested() }
                    MenuItem { text: "Reveal in folder"; onTriggered: root.revealRequested() }
                    MenuSeparator {}
                    MenuItem { text: "Delete"; onTriggered: root.deleteRequested() }
                }
            }

            EmptyState {
                anchors.centerIn: parent
                visible: files.count === 0
                icon: vault.filter !== "" ? "search" : "document"
                title: vault.filter !== "" ? "No results" : "No notes yet"
                hint: vault.filter !== "" ? "Try a different search" : "Press Ctrl+N to create one"
            }
        }

        // ---- footer
        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: AppTheme.line }
        RowLayout {
            Layout.fillWidth: true
            Layout.margins: AppTheme.space2
            spacing: AppTheme.space0

            Rectangle {
                id: vaultBtn
                Layout.fillWidth: true
                implicitHeight: AppTheme.ctrlMd
                radius: AppTheme.radiusMd
                color: vaultArea.containsMouse ? AppTheme.hover : "transparent"
                RowLayout {
                    anchors { fill: parent; leftMargin: AppTheme.space2; rightMargin: AppTheme.space2 }
                    spacing: AppTheme.space2
                    Icon { kind: "folder_open"; col: AppTheme.muted }
                    Text {
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        text: vault.name
                        color: AppTheme.muted
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontSm
                    }
                }
                MouseArea {
                    id: vaultArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.openVault()
                }
                Tip { parent: vaultBtn; text: vault.noteCount + " notes · open another vault (Ctrl+O)"; show: vaultArea.containsMouse }
            }
            ToolBtn { iconOnly: true; iconKind: "calendar"; tip: "Activity"; onClicked: root.openActivity() }
            ToolBtn { iconOnly: true; iconKind: "settings"; tip: "Settings (Ctrl+,)"; onClicked: root.openSettings() }
        }
    }
}
