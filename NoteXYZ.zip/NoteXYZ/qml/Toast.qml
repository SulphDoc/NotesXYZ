import QtQuick

// Adwaita-style toast: a dark pill that fits its text, with an optional action.
//   toast.show("Deleted note", "Undo")   ->  emits actionClicked() when the action is pressed
Rectangle {
    id: root
    property string text: ""
    property string actionText: ""
    property bool shown: false
    signal actionClicked()

    function show(msg, action) {
        text = msg
        actionText = action || ""
        shown = true
        hideTimer.restart()
    }

    implicitHeight: AppTheme.ctrlLg
    implicitWidth: row.implicitWidth + AppTheme.space4 + (actionText !== "" ? AppTheme.space1 : AppTheme.space4)
    radius: AppTheme.radiusLg                       // inner button: 12 - 4 = 8 = radiusMd
    color: AppTheme.toastBg
    visible: opacity > 0
    opacity: shown ? 1 : 0
    transform: Translate { y: root.shown ? 0 : AppTheme.space2; Behavior on y { NumberAnimation { duration: AppTheme.motionFast } } }
    Behavior on opacity { NumberAnimation { duration: AppTheme.motionFast } }

    Elevation { radius: root.radius; lift: 0.6 }
    Timer { id: hideTimer; interval: 3200; onTriggered: root.shown = false }

    Row {
        id: row
        x: AppTheme.space4
        anchors.verticalCenter: parent.verticalCenter
        spacing: AppTheme.space3

        Text {
            anchors.verticalCenter: parent.verticalCenter
            width: Math.min(implicitWidth, 360)
            elide: Text.ElideRight
            text: root.text
            color: "#ffffff"
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontMd
        }
        Rectangle {
            visible: root.actionText !== ""
            anchors.verticalCenter: parent.verticalCenter
            width: actionLabel.implicitWidth + AppTheme.space4
            height: AppTheme.ctrlMd
            radius: AppTheme.inner(root.radius, AppTheme.space1)
            color: actionArea.containsMouse ? "#26ffffff" : "transparent"
            Text {
                id: actionLabel
                anchors.centerIn: parent
                text: root.actionText
                color: "#ffffff"
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontMd
                font.weight: Font.DemiBold
            }
            MouseArea {
                id: actionArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: { root.shown = false; root.actionClicked() }
            }
        }
    }
}
