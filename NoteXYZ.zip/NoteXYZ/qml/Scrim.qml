import QtQuick

// Dimmed backdrop behind a modal overlay. Clicking it emits clicked().
Rectangle {
    id: root
    signal clicked()
    anchors.fill: parent
    color: AppTheme.overlayDim
    MouseArea { anchors.fill: parent; onClicked: root.clicked() }
}
