import QtQuick

// Small heading above a group of controls. Keep it closer to its own group than to the previous one.
Text {
    color: AppTheme.muted
    font.family: AppTheme.ui
    font.pixelSize: AppTheme.fontSm
    font.weight: Font.DemiBold
}
