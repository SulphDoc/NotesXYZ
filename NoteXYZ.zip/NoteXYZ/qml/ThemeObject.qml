import QtQuick

// NoteXYZ design tokens. Style target: GNOME x macOS.
//   from GNOME: flat full-width headerbars, hairlines, Adwaita icons, dark toasts, calm accent tints
//   from macOS: translucent fills for hover/fields, sliding segmented control, soft shadows, source-list sidebar
// Read AGENT.md before changing anything here. Never hardcode a colour, radius, size or duration in a component.
QtObject {
    readonly property bool dark: vault.dark

    // ---- accent palettes: [text/icon, fill, fill hover, soft tint] per theme
    readonly property var palettes: [
        { name: "Teal",  dt: "#62c6b8", df: "#1f877b", dh: "#2a9a8d", ds: "#1f3a37",
                         lt: "#0b7a6e", lf: "#0f8a7c", lh: "#0c7467", ls: "#d9f0ec" },
        { name: "Blue",  dt: "#78aeed", df: "#2f74d0", dh: "#3d84e2", ds: "#1f3550",
                         lt: "#1c71d8", lf: "#2f74d0", lh: "#2565b8", ls: "#dce8fa" },
        { name: "Coral", dt: "#ff9f8f", df: "#d4553f", dh: "#e2664f", ds: "#46241f",
                         lt: "#c0392b", lf: "#d4553f", lh: "#bb4631", ls: "#fbe1db" }
    ]
    readonly property var pal: palettes[Math.max(0, Math.min(palettes.length - 1, vault.accent))]
    readonly property color accent:      dark ? pal.dt : pal.lt
    readonly property color accentFill:  dark ? pal.df : pal.lf
    readonly property color accentHover: dark ? pal.dh : pal.lh
    readonly property color accentSoft:  dark ? pal.ds : pal.ls
    readonly property color accentOn: "#ffffff"
    readonly property color focusRing: Qt.rgba(accent.r, accent.g, accent.b, 0.7)

    // ---- surfaces (content < sidebar < raised)
    readonly property color bg:      dark ? "#1e1e1e" : "#fdfdfd"   // content area
    readonly property color panel:   dark ? "#262626" : "#f3f3f3"   // sidebar
    readonly property color surface: dark ? "#2e2e2e" : "#ffffff"   // dialogs, popovers
    readonly property color thumb:   dark ? "#4a4a4a" : "#ffffff"   // raised thumb in segmented control
    readonly property color toastBg: dark ? "#3c3c3c" : "#303030"   // Adwaita toasts are dark in both themes
    readonly property color overlayDim: dark ? "#80000000" : "#4d000000"

    // ---- translucent fills: work on any surface (macOS style)
    readonly property color hover:   dark ? "#0fffffff" : "#0d000000"
    readonly property color pressed: dark ? "#1affffff" : "#17000000"
    readonly property color trough:  dark ? "#14ffffff" : "#0f000000"   // fields, segmented track

    // ---- hairlines
    readonly property color line:         dark ? "#1affffff" : "#1a000000"
    readonly property color borderStrong: dark ? "#33ffffff" : "#29000000"

    // ---- text
    readonly property color fg:    dark ? "#f2f2f2" : "#1f1f1f"
    readonly property color muted: dark ? "#adadad" : "#555555"
    readonly property color faint: dark ? "#8e8e8e" : "#6b6b6b"

    // ---- status
    readonly property color danger:     dark ? "#ff6b5e" : "#c7261b"
    readonly property color dangerSoft: dark ? "#3a1f1c" : "#fbe3e0"
    readonly property color warning:    dark ? "#f0b45a" : "#a15c00"

    // ---- graph canvas
    readonly property color graphBg:    bg
    readonly property color graphEdge:  dark ? "#3d3d3d" : "#d4d4d4"
    readonly property color nodeBg:     dark ? "#333333" : "#ececec"
    readonly property color nodeBorder: dark ? "#555555" : "#b8b8b8"

    // ---- radii: Sm for 24px controls, Md for 32px controls, Lg for cards and dialogs.
    // Nested corners must be concentric: inner = inner(outer, gap).
    readonly property int radiusXs: 4
    readonly property int radiusSm: 6
    readonly property int radiusMd: 8
    readonly property int radiusLg: 12
    readonly property int radiusCell: 2     // heatmap cells
    function inner(outer, gap) { return Math.max(0, outer - gap) }

    // ---- control heights (every button, field and row is one of these)
    readonly property int ctrlSm: 24
    readonly property int ctrlMd: 32
    readonly property int ctrlLg: 40
    readonly property int barH: 48          // top bar
    readonly property int statusH: 28
    readonly property int sidebarW: 248
    readonly property int readingW: 720     // max width of the text column

    // ---- spacing: 4pt grid
    readonly property int space0: 2
    readonly property int space1: 4
    readonly property int space2: 8
    readonly property int space3: 12
    readonly property int space4: 16
    readonly property int space5: 24
    readonly property int space6: 32
    readonly property int gutter: 16
    readonly property int dialogPad: 24

    // ---- type
    readonly property string ui: uiFontFamily
    readonly property string mono: "monospace"
    readonly property int fontXs: 11
    readonly property int fontSm: 12
    readonly property int fontMd: 13
    readonly property int fontLg: 14
    readonly property int fontXl: 16
    readonly property int fontXxl: 20
    readonly property int fontDisplay: 32

    // ---- motion
    readonly property int motionFast: 120
    readonly property int motionSlow: 220
}
