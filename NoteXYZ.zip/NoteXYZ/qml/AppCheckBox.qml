import QtQuick
import QtQuick.Controls

CheckBox {
    id: c
    spacing: AppTheme.space2
    hoverEnabled: true

    indicator: Rectangle {
        implicitWidth: 20
        implicitHeight: 20
        x: c.leftPadding
        y: c.topPadding + (c.availableHeight - height) / 2
        radius: AppTheme.radiusSm
        color: c.checked ? AppTheme.accentFill : (c.hovered ? AppTheme.pressed : AppTheme.trough)
        border.width: c.visualFocus ? 2 : 1
        border.color: c.visualFocus ? AppTheme.focusRing : (c.checked ? "transparent" : AppTheme.borderStrong)

        Icon {
            anchors.centerIn: parent
            visible: c.checked
            kind: "check"
            col: AppTheme.accentOn
        }
    }
    contentItem: Text {
        leftPadding: c.indicator.width + c.spacing
        text: c.text
        verticalAlignment: Text.AlignVCenter
        color: AppTheme.fg
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontMd
    }
}
