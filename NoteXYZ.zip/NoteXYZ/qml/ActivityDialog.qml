import QtQuick
import QtQuick.Layouts

// Year heatmap: words written and time open per day for the last 365 days.
// The data is recorded by the vault and stored locally (QSettings); nothing leaves this device.
AppDialog {
    id: dlg
    signal todayRequested()

    readonly property int gap: 3
    readonly property int labelW: 32
    readonly property int cols: 53
    readonly property int cell: Math.max(8, Math.floor((availableWidth - labelW + gap) / cols) - gap)
    readonly property int gridTop: 20

    property string hoverDate: ""
    property var hoverInfo: null

    readonly property var days: visible ? vault.activity : []

    // ---- helpers
    function parseDate(iso) {
        const p = iso.split("-")
        return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]))
    }
    function fmtNum(n) { return Number(n).toLocaleString(Qt.locale(), "f", 0) }
    function fmtTime(m) {
        const h = Math.floor(m / 60)
        return h > 0 ? h + "h " + (m % 60) + "m" : m + "m"
    }
    function levelColor(words) {
        if (words <= 0) return AppTheme.trough
        const r = words / Math.max(1, stats.max)
        const a = r < 0.25 ? 0.35 : r < 0.5 ? 0.6 : r < 0.75 ? 0.8 : 1
        const c = AppTheme.accentFill
        return Qt.rgba(c.r, c.g, c.b, a)
    }

    // ---- derived data
    // Cells in column-major order (7 rows per week, Monday first). null = padding before the first day.
    readonly property var cells: {
        const d = days
        if (d.length === 0) return []
        const offset = (parseDate(d[0].date).getDay() + 6) % 7
        const out = []
        for (let i = 0; i < offset; i++) out.push(null)
        for (const x of d) out.push(x)
        while (out.length % 7 !== 0) out.push(null)
        return out
    }
    readonly property var months: {
        const out = []
        let last = -1
        let lastCol = -10
        for (let c = 0; c * 7 < cells.length; c++) {
            let day = null
            for (let r = 0; r < 7 && !day; r++) day = cells[c * 7 + r]
            if (!day) continue
            const m = parseDate(day.date).getMonth()
            if (m !== last) {
                if (out.length > 0 && c - lastCol < 3) out.pop()      // a short partial month gives way to the next one
                out.push({ col: c, name: Qt.locale().monthName(m, Locale.ShortFormat) })
                lastCol = c
            }
            last = m
        }
        return out
    }
    readonly property var stats: {
        let words = 0, active = 0, minutes = 0, max = 0, streak = 0
        const d = days
        for (const x of d) {
            words += x.words
            minutes += x.minutes
            if (x.words > 0) active++
            if (x.words > max) max = x.words
        }
        let i = d.length - 1
        if (i >= 0 && d[i].words === 0) i--          // today may still be empty without breaking the streak
        while (i >= 0 && d[i].words > 0) { streak++; i-- }
        return { words: words, active: active, minutes: minutes, max: max, streak: streak }
    }
    readonly property var cards: [
        { value: fmtNum(stats.words), label: "words written" },
        { value: String(stats.active), label: "active days" },
        { value: stats.streak + (stats.streak === 1 ? " day" : " days"), label: "current streak" },
        { value: fmtTime(stats.minutes), label: "time open" }
    ]

    onClosed: { hoverDate = ""; hoverInfo = null }

    contentItem: ColumnLayout {
        spacing: AppTheme.space4

        // ---- header
        RowLayout {
            Layout.fillWidth: true
            spacing: AppTheme.space2
            ColumnLayout {
                spacing: AppTheme.space0
                Text {
                    text: "Activity"
                    color: AppTheme.fg
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXl
                    font.weight: Font.DemiBold
                }
                Text {
                    text: "Last 365 days · stored only on this device"
                    color: AppTheme.faint
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontSm
                }
            }
            Item { Layout.fillWidth: true }
            ToolBtn { text: "Today’s note"; iconKind: "calendar"; onClicked: dlg.todayRequested() }
            ToolBtn { iconOnly: true; iconKind: "close"; tip: "Close (Esc)"; onClicked: dlg.close() }
        }

        // ---- totals
        RowLayout {
            Layout.fillWidth: true
            spacing: AppTheme.space6
            Repeater {
                model: dlg.cards
                delegate: Column {
                    required property var modelData
                    spacing: AppTheme.space0
                    Text {
                        text: parent.modelData.value
                        color: AppTheme.fg
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontXxl
                        font.weight: Font.Bold
                    }
                    Text {
                        text: parent.modelData.label
                        color: AppTheme.muted
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontSm
                    }
                }
            }
        }

        // ---- heatmap
        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: dlg.gridTop + 7 * dlg.cell + 6 * dlg.gap

            Repeater {
                model: dlg.months
                delegate: Text {
                    required property var modelData
                    x: dlg.labelW + modelData.col * (dlg.cell + dlg.gap)
                    text: modelData.name
                    color: AppTheme.faint
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXs
                }
            }
            Repeater {
                model: ["Mon", "", "Wed", "", "Fri", "", ""]
                delegate: Text {
                    required property string modelData
                    required property int index
                    y: dlg.gridTop + index * (dlg.cell + dlg.gap)
                    height: dlg.cell
                    verticalAlignment: Text.AlignVCenter
                    text: modelData
                    color: AppTheme.faint
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXs
                }
            }
            Grid {
                x: dlg.labelW
                y: dlg.gridTop
                rows: 7
                flow: Grid.TopToBottom
                rowSpacing: dlg.gap
                columnSpacing: dlg.gap
                Repeater {
                    model: dlg.cells
                    delegate: Rectangle {
                        id: dayCell
                        required property var modelData
                        readonly property bool real: modelData !== null
                        width: dlg.cell
                        height: dlg.cell
                        radius: AppTheme.radiusCell
                        opacity: real ? 1 : 0          // padding cells keep their slot (visible:false would collapse it)
                        color: real ? dlg.levelColor(modelData.words) : "transparent"
                        border.width: real && modelData.date === dlg.hoverDate ? 1 : 0
                        border.color: AppTheme.fg

                        MouseArea {
                            anchors.fill: parent
                            enabled: dayCell.real
                            hoverEnabled: true
                            onEntered: { dlg.hoverDate = dayCell.modelData.date; dlg.hoverInfo = dayCell.modelData }
                            onExited: if (dlg.hoverDate === dayCell.modelData.date) { dlg.hoverDate = ""; dlg.hoverInfo = null }
                        }
                    }
                }
            }
        }

        // ---- hover details + legend
        RowLayout {
            Layout.fillWidth: true
            spacing: AppTheme.space3
            Text {
                Layout.fillWidth: true
                elide: Text.ElideRight
                text: dlg.hoverInfo
                      ? Qt.formatDate(dlg.parseDate(dlg.hoverInfo.date), "ddd, d MMM yyyy") + "  ·  "
                        + (dlg.hoverInfo.words > 0 ? dlg.fmtNum(dlg.hoverInfo.words) + " words" : "no writing")
                        + "  ·  " + dlg.fmtTime(dlg.hoverInfo.minutes) + " open"
                      : "Hover a day for details"
                color: dlg.hoverInfo ? AppTheme.fg : AppTheme.faint
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontSm
            }
            Text {
                text: "Less"
                color: AppTheme.faint
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontXs
            }
            Row {
                spacing: dlg.gap
                Repeater {
                    model: [0, 0.2, 0.45, 0.7, 1]
                    delegate: Rectangle {
                        required property real modelData
                        width: dlg.cell
                        height: dlg.cell
                        radius: AppTheme.radiusCell
                        color: modelData === 0 ? AppTheme.trough : dlg.levelColor(modelData * Math.max(1, dlg.stats.max))
                    }
                }
            }
            Text {
                text: "More"
                color: AppTheme.faint
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontXs
            }
        }
    }
}
