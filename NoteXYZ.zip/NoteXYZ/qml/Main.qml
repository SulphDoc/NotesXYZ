import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

// Window shell: state, shortcuts, and layout. Every visible piece is its own component.
ApplicationWindow {
    id: win
    width: 1180
    height: 760
    minimumWidth: 780
    minimumHeight: 480
    visible: true
    title: "NoteXYZ" + (vault.currentName ? " — " + vault.currentName.replace(/\.md$/i, "") : "")
    color: AppTheme.bg

    // ---- state
    property string mode: "edit"            // edit | split | preview
    property bool showGraph: false
    property bool showSettings: false
    property bool paletteOpen: false
    property bool outlineOpen: false
    property string docPath: ""
    property var docPages: []
    readonly property var modes: ["edit", "split", "preview"]
    readonly property bool hasNote: vault.currentPath !== ""
    readonly property string parentFolder: {
        if (!hasNote || vault.root === "") return ""
        const parts = vault.currentPath.substring(vault.root.length + 1).split("/")
        return parts.length > 1 ? parts[parts.length - 2] : ""
    }

    // ---- actions
    function setView(i) {
        if (i === 3) showGraph = true
        else { showGraph = false; mode = modes[i] }
    }
    function openToday() {
        const p = vault.todayNote()
        if (p) { showGraph = false; vault.openFile(p) }
    }
    function openDoc(path) {
        if (!vault.fileExists(path)) {
            if (path.indexOf("http://") === 0 || path.indexOf("https://") === 0
                    || path.indexOf("mailto:") === 0) Qt.openUrlExternally(path)
            return
        }
        docPath = path
        docPages = docRender.cachedImages(path)
        if (docPages.length === 0) docRender.render(path)
    }
    function manualSave() {
        if (hasNote && vault.dirty) { vault.save(); toast.show("Saved") }
    }
    function undoDelete() {
        if (!vault.restoreLastDeleted()) toast.show("Nothing to undo")
    }
    function refreshVault() {
        vault.refresh()
        if (showGraph) graphView.reload()
    }
    function exportCurrent() {
        if (!hasNote) { toast.show("Open a note first"); return }
        const p = vault.exportNoteHtml(vault.currentPath)
        toast.show(p ? "Exported " + p.split("/").pop() : "Could not export")
    }
    function handleAction(id) {
        paletteOpen = false
        switch (id) {
        case "new": nameDialog.openFor("note"); break
        case "today": openToday(); break
        case "activity": activityDialog.open(); break
        case "folder": nameDialog.openFor("folder"); break
        case "open": folderDialog.open(); break
        case "edit": case "split": case "preview": showGraph = false; mode = id; break
        case "graph": showGraph = !showGraph; break
        case "sidebar": vault.focusMode = !vault.focusMode; break
        case "outline": outlineOpen = !outlineOpen; break
        case "export": exportCurrent(); break
        case "undo": undoDelete(); break
        case "theme": vault.dark = !vault.dark; break
        case "accent": vault.accent = (vault.accent + 1) % AppTheme.palettes.length; break
        case "refresh": refreshVault(); break
        case "settings": showSettings = true; break
        case "shortcuts": settingsPanel.page = 3; showSettings = true; break
        }
    }

    onClosing: vault.save()

    FolderDialog {
        id: folderDialog
        title: "Open vault"
        currentFolder: vault.root !== "" ? "file://" + vault.root : ""
        onAccepted: vault.openVault(selectedFolder)
    }

    // ---- shortcuts (keep ShortcutList.qml in sync)
    Shortcut { sequence: "Ctrl+S"; onActivated: win.manualSave() }
    Shortcut { sequence: "Ctrl+O"; onActivated: folderDialog.open() }
    Shortcut { sequence: "Ctrl+N"; onActivated: if (vault.root !== "") nameDialog.openFor("note") }
    Shortcut { sequence: "Ctrl+Shift+N"; onActivated: if (vault.root !== "") nameDialog.openFor("folder") }
    Shortcut { sequence: "Ctrl+G"; onActivated: if (vault.root !== "") win.showGraph = !win.showGraph }
    Shortcut { sequence: "Ctrl+F"; onActivated: { if (vault.root !== "") { vault.focusMode = false; sidebar.focusSearch() } } }
    Shortcut { sequence: "Ctrl+1"; onActivated: win.setView(0) }
    Shortcut { sequence: "Ctrl+2"; onActivated: win.setView(1) }
    Shortcut { sequence: "Ctrl+3"; onActivated: win.setView(2) }
    Shortcut { sequence: "Ctrl+R"; onActivated: win.refreshVault() }
    Shortcut { sequence: "Ctrl+Shift+D"; onActivated: vault.dark = !vault.dark }
    Shortcut { sequence: "Ctrl+,"; onActivated: win.showSettings = !win.showSettings }
    Shortcut { sequence: "Ctrl+="; onActivated: vault.fontSize = vault.fontSize + 1 }
    Shortcut { sequence: "Ctrl+-"; onActivated: vault.fontSize = vault.fontSize - 1 }
    Shortcut { sequence: "Ctrl+K"; onActivated: win.paletteOpen = true }
    Shortcut { sequence: "Ctrl+B"; onActivated: vault.focusMode = !vault.focusMode }
    Shortcut { sequence: "Ctrl+Z"; onActivated: win.undoDelete() }
    Shortcut { sequence: "Ctrl+Shift+O"; onActivated: win.outlineOpen = !win.outlineOpen }
    Shortcut { sequence: "?"; onActivated: win.handleAction("shortcuts") }
    Shortcut {
        sequence: "Escape"
        enabled: !nameDialog.visible && !deleteDialog.visible
        onActivated: {
            if (win.paletteOpen) win.paletteOpen = false
            else if (win.showSettings) win.showSettings = false
            else if (win.outlineOpen) win.outlineOpen = false
            else if (win.showGraph) win.showGraph = false
            else if (vault.filter !== "") sidebar.clearSearch()
        }
    }

    Connections {
        target: vault
        function onStatusChanged() {
            const s = vault.status
            // Autosave is silent: the status bar already shows "Saved".
            if (s === "" || s.indexOf("Saved ") === 0) return
            toast.show(s.replace(" · Ctrl+Z to undo", ""), s.indexOf("Deleted") === 0 ? "Undo" : "")
        }
        function onExternalChange(p) { if (p === vault.currentPath) vault.reloadCurrent() }
    }

    Connections {
        target: docRender
        function onFinished(images) { docPages = images }
        function onFailed(message) { toast.show(message) }
    }

    // ---- dialogs
    NameDialog { id: nameDialog }
    DeleteDialog { id: deleteDialog }
    ActivityDialog {
        id: activityDialog
        width: Math.min(820, win.width - AppTheme.space6 * 2)
        onTodayRequested: { close(); win.openToday() }
    }

    // ---- start screen
    Start {
        anchors.fill: parent
        visible: vault.root === ""
        onOpenVaultRequested: folderDialog.open()
    }

    // ---- main layout: sidebar | (top bar, content, status bar) | outline
    RowLayout {
        anchors.fill: parent
        visible: vault.root !== ""
        spacing: 0

        Sidebar {
            id: sidebar
            visible: !vault.focusMode
            Layout.preferredWidth: AppTheme.sidebarW
            Layout.fillHeight: true
            onOpenVault: folderDialog.open()
            onOpenActivity: activityDialog.open()
            onOpenSettings: win.showSettings = true
            onNoteOpened: win.showGraph = false
            onRenameRequested: nameDialog.openFor("rename")
            onDuplicateRequested: { vault.duplicateCurrent() }
            onDeleteRequested: deleteDialog.open()
            onRevealRequested: Qt.openUrlExternally("file://" + vault.currentPath)
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            TopBar {
                Layout.fillWidth: true
                title: vault.currentName ? vault.currentName.replace(/\.md$/i, "") : "No note"
                folder: win.parentFolder
                hasNote: win.hasNote
                sidebarHidden: vault.focusMode
                viewIndex: win.showGraph ? 3 : win.modes.indexOf(win.mode)
                onShowSidebar: vault.focusMode = false
                onNewNoteRequested: nameDialog.openFor("note")
                onNewFolderRequested: nameDialog.openFor("folder")
                onRenameRequested: nameDialog.openFor("rename")
                onDeleteRequested: deleteDialog.open()
                onSaveRequested: win.manualSave()
                onViewPicked: (i) => win.setView(i)
            }

            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                SplitView {
                    id: split
                    anchors.fill: parent
                    visible: !win.showGraph
                    orientation: Qt.Horizontal

                    // On release, snap the divider to the nearest quarter with a
                    // short slide. No preview, no toast — the motion is the feedback.
                    function snapDivider() {
                        if (win.mode !== "split" || split.width <= 0) return
                        const share = Math.max(0.2, Math.min(0.8, editor.width / split.width))
                        let target = 0.5
                        let best = Math.abs(share - 0.5)
                        for (const t of [0.25, 0.5, 0.75]) {
                            const d = Math.abs(share - t)
                            if (d < best) { best = d; target = t }
                        }
                        snapAnim.to = Math.max(240, Math.round(split.width * (1 - target)))
                        snapAnim.restart()
                    }

                    NumberAnimation {
                        id: snapAnim
                        target: previewPane
                        property: "SplitView.preferredWidth"
                        duration: AppTheme.motionFast
                        easing.type: Easing.OutCubic
                    }

                    handle: Item {
                        id: grip
                        implicitWidth: 9
                        SplitHandle.onPressedChanged: {
                            if (!grip.SplitHandle.pressed) split.snapDivider()
                        }
                        Rectangle {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: 1
                            height: parent.height
                            color: grip.SplitHandle.pressed ? AppTheme.accent
                                 : grip.SplitHandle.hovered ? AppTheme.borderStrong : AppTheme.line
                        }
                    }

                    TextPane {
                        id: editor
                        visible: win.mode !== "preview"
                        SplitView.fillWidth: true
                        SplitView.minimumWidth: 240
                        onDocLinkActivated: (p) => openDoc(p)
                    }
                    TextPane {
                        id: previewPane
                        preview: true
                        visible: win.mode !== "edit"
                        SplitView.fillWidth: win.mode === "preview"
                        SplitView.preferredWidth: Math.round(split.width / 2)
                        SplitView.minimumWidth: 240
                        onDocLinkActivated: (p) => openDoc(p)
                    }
                    DocPane {
                        id: docPane
                        visible: win.docPath !== ""
                        pages: win.docPages
                        SplitView.preferredWidth: Math.round(split.width / 2)
                        SplitView.minimumWidth: 240
                        onCloseRequested: win.docPath = ""
                    }
                }

                EmptyState {
                    anchors.centerIn: parent
                    visible: !win.hasNote && !win.showGraph
                    icon: "document"
                    title: "No note selected"
                    hint: "Pick one from the sidebar or press Ctrl+N"
                }

                Graph {
                    id: graphView
                    anchors.fill: parent
                    visible: win.showGraph
                    onNoteClicked: (p) => { win.showGraph = false; vault.openFile(p) }
                    onCloseRequested: win.showGraph = false
                }
            }

            StatusBar { Layout.fillWidth: true }
        }

        OutlinePanel {
            visible: win.outlineOpen && win.hasNote && !win.showGraph
            Layout.preferredWidth: 240
            Layout.fillHeight: true
            onCloseRequested: win.outlineOpen = false
            onHeadingClicked: (pos) => {
                if (win.mode === "preview") win.mode = "edit"
                editor.area.cursorPosition = pos
                editor.area.forceActiveFocus()
            }
        }
    }

    // ---- overlays (higher z = closer to the user)
    Scrim { z: 100; visible: win.paletteOpen; onClicked: win.paletteOpen = false }
    CommandPalette {
        id: palette
        z: 101
        open: win.paletteOpen
        onCloseRequested: win.paletteOpen = false
        onNoteSelected: (p) => { win.paletteOpen = false; win.showGraph = false; vault.openFile(p) }
        onActionSelected: (id) => win.handleAction(id)
    }

    Item {
        anchors.fill: parent
        z: 110
        visible: win.showSettings
        Scrim { onClicked: win.showSettings = false }
        Settings {
            id: settingsPanel
            anchors.centerIn: parent
            onCloseRequested: win.showSettings = false
            onOpenVaultRequested: { win.showSettings = false; folderDialog.open() }
            onReplayWelcome: { win.showSettings = false; vault.onboarded = false }
            onExportRequested: { win.showSettings = false; win.exportCurrent() }
            onExportZipRequested: {
                const p = vault.exportAllZip()
                win.showSettings = false
                toast.show(p ? "Backup created" : "Backup failed")
            }
        }
    }

    Onboarding {
        z: 120
        open: !vault.onboarded
        onOpenVaultRequested: folderDialog.open()
        onFinished: vault.onboarded = true
    }

    Toast {
        id: toast
        z: 130
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: AppTheme.statusH + AppTheme.space5 }
        onActionClicked: win.undoDelete()
    }
}
