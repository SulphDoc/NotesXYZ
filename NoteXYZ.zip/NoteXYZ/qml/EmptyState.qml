import QtQuick

// Centered icon + title + hint. Use for every "nothing here yet" state.
Column {
    property string icon: "document"
    property string title: ""
    property string hint: ""
    spacing: AppTheme.space2

    Icon {
        anchors.horizontalCenter: parent.horizontalCenter
        kind: parent.icon
        size: 32
        col: AppTheme.faint
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        text: parent.title
        color: AppTheme.muted
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontLg
        font.weight: Font.DemiBold
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        visible: text !== ""
        text: parent.hint
        color: AppTheme.faint
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontSm
    }
}
