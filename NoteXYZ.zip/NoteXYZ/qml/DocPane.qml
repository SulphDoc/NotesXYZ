import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Page viewer for a linked PDF or presentation. Shows cached page images.
Rectangle {
    id: root
    property var pages: []
    signal closeRequested()
    property real zoom: 1.0

    color: AppTheme.panel
    clip: true

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: AppTheme.ctrlMd
            Layout.margins: AppTheme.space2
            Text {
                text: "Document"
                color: AppTheme.fg
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontLg
                font.weight: Font.DemiBold
                Layout.fillWidth: true
                elide: Text.ElideRight
            }
            ToolBtn {
                iconOnly: true
                iconKind: "remove"
                tip: "Zoom out"
                onClicked: root.zoom = Math.max(0.5, root.zoom - 0.15)
            }
            Text {
                text: Math.round(root.zoom * 100) + "%"
                color: AppTheme.muted
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontSm
            }
            ToolBtn {
                iconOnly: true
                iconKind: "add"
                tip: "Zoom in"
                onClicked: root.zoom = Math.min(3.0, root.zoom + 0.15)
            }
            ToolBtn {
                iconOnly: true
                iconKind: "close"
                tip: "Close document"
                onClicked: root.closeRequested()
            }
        }

        Rectangle { Layout.fillWidth: true; height: 1; color: AppTheme.line }

        Flickable {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            contentWidth: Math.max(width, col.implicitWidth * root.zoom)
            contentHeight: col.implicitHeight * root.zoom
            WheelHandler {
                onWheel: (e) => root.zoom = Math.max(0.5, Math.min(3.0,
                    root.zoom + (e.angleDelta.y > 0 ? 0.1 : -0.1)))
            }
            Column {
                id: col
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: AppTheme.space2
                Repeater {
                    model: root.pages
                    delegate: Image {
                        source: "file://" + modelData
                        smooth: true
                        width: Math.min(root.width - AppTheme.space4, 760) * root.zoom
                        fillMode: Image.PreserveAspectFit
                        Rectangle {
                            anchors.fill: parent
                            z: -1
                            color: AppTheme.surface
                        }
                    }
                }
            }
        }

        EmptyState {
            Layout.alignment: Qt.AlignCenter
            visible: root.pages.length === 0
            icon: "document"
            title: "Rendering…"
            hint: "Preparing the first page"
        }
    }
}
