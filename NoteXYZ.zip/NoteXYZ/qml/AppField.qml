import QtQuick
import QtQuick.Controls

// The one text field. Optional leading icon and clear button.
TextField {
    id: f
    property string leadingIcon: ""
    property bool clearable: false
    readonly property bool showClear: clearable && text !== ""

    implicitHeight: AppTheme.ctrlMd
    leftPadding: leadingIcon !== "" ? AppTheme.space3 + 16 + AppTheme.space2 : AppTheme.space3
    rightPadding: showClear ? AppTheme.ctrlSm + AppTheme.space2 : AppTheme.space3
    verticalAlignment: TextInput.AlignVCenter
    selectByMouse: true
    color: AppTheme.fg
    placeholderTextColor: AppTheme.faint
    selectionColor: AppTheme.accentFill
    selectedTextColor: AppTheme.accentOn
    font.family: AppTheme.ui
    font.pixelSize: AppTheme.fontMd

    background: Rectangle {
        radius: AppTheme.radiusMd
        color: AppTheme.trough
        border.width: f.activeFocus ? 2 : 0
        border.color: AppTheme.focusRing
    }

    Icon {
        visible: f.leadingIcon !== ""
        anchors { left: parent.left; leftMargin: AppTheme.space3; verticalCenter: parent.verticalCenter }
        kind: f.leadingIcon
        col: AppTheme.faint
    }
    ToolBtn {
        visible: f.showClear
        anchors { right: parent.right; rightMargin: AppTheme.space1; verticalCenter: parent.verticalCenter }
        iconOnly: true
        iconKind: "close"
        tip: "Clear"
        implicitHeight: AppTheme.ctrlSm
        cornerRadius: AppTheme.inner(AppTheme.radiusMd, AppTheme.space1)
        onClicked: { f.clear(); f.forceActiveFocus() }
    }
}
