import QtQuick
import QtQuick.Controls

// Tooltip. Usage inside any item:  Tip { parent: item; text: "Save"; show: item.hovered }
ToolTip {
    id: tip
    property bool show: false

    visible: show && text !== ""
    delay: 400
    padding: AppTheme.space2
    x: Math.round((parent.width - width) / 2)
    y: parent.height + AppTheme.space1 + AppTheme.space0

    background: Rectangle {
        color: AppTheme.surface
        radius: AppTheme.radiusSm
        border.width: 1
        border.color: AppTheme.borderStrong
    }
    contentItem: Text {
        text: tip.text
        color: AppTheme.fg
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontSm
    }
}
