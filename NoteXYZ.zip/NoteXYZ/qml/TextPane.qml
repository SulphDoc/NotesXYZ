import QtQuick
import QtQuick.Controls

// Scrollable text column centred at a readable width. Used for both the editor and the preview.
ScrollView {
    id: root
    property bool preview: false
    property alias area: input
    signal docLinkActivated(string path)

    clip: true
    // A SplitView sizes us by fillWidth; pin implicitWidth so the TextArea's
    // content width cannot feed back into layout (binding loop).
    implicitWidth: 0
    ScrollBar.vertical: ThinScrollBar {}
    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

    TextArea {
        id: input
        text: root.preview ? vault.previewHtml : vault.text
        readOnly: root.preview
        enabled: root.preview || vault.currentPath !== ""
        textFormat: root.preview ? TextEdit.RichText : TextEdit.PlainText
        placeholderText: !root.preview && vault.currentPath !== "" ? "Start writing…" : ""
        placeholderTextColor: AppTheme.faint
        wrapMode: TextEdit.Wrap
        selectByMouse: true
        color: AppTheme.fg
        selectionColor: AppTheme.accentFill
        selectedTextColor: AppTheme.accentOn
        font.family: AppTheme.ui
        font.pixelSize: vault.fontSize
        leftPadding: Math.max(AppTheme.space5, (root.availableWidth - vault.readingWidth) / 2)
        rightPadding: leftPadding
        topPadding: AppTheme.space5
        bottomPadding: AppTheme.space5
        background: null

        onTextChanged: if (!root.preview && text !== vault.text) vault.text = text
        onCursorPositionChanged: {
            if (!vault.typewriter || root.preview) return
            const r = input.positionToRectangle(input.cursorPosition)
            const flick = root.contentItem
            flick.contentY = Math.max(0, r.y + r.height / 2 - flick.height / 2)
        }
        onLinkActivated: (link) => {
            const lower = link.toLowerCase()
            if (lower.indexOf(".pdf") !== -1 || lower.indexOf(".ppt") !== -1
                    || lower.indexOf(".pptx") !== -1 || lower.indexOf(".odp") !== -1) {
                let p = link
                if (p.indexOf("file://") === 0) p = p.substring(7)
                else if (!p.startsWith("/")) p = vault.root + "/" + p
                root.docLinkActivated(p)
            } else if (link.indexOf("wiki:") === 0) {
                vault.openByName(link.substring(5))
            } else if (link.indexOf("http://") === 0 || link.indexOf("https://") === 0
                       || link.indexOf("mailto:") === 0) {
                Qt.openUrlExternally(link)
            }
        }
    }
}
