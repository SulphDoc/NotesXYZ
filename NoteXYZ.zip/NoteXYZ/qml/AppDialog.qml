import QtQuick
import QtQuick.Controls

// Modal dialog frame shared by every confirm / prompt dialog.
Dialog {
    modal: true
    parent: Overlay.overlay
    anchors.centerIn: Overlay.overlay
    width: 400
    padding: AppTheme.dialogPad
    header: null
    footer: null
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

    Overlay.modal: Rectangle { color: AppTheme.overlayDim }

    background: Rectangle {
        color: AppTheme.surface
        radius: AppTheme.radiusLg
        border.width: 1
        border.color: AppTheme.borderStrong
        Elevation { radius: AppTheme.radiusLg }
    }
}
