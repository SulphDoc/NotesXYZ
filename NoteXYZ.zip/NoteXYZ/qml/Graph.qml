import QtQuick

// Map of the vault. Vault::graph() runs a force layout (folder tree springs,
// weaker wiki-link springs, collision) and returns normalised x/y per node;
// this file only draws it. Folders are rounded squares, notes are discs sized
// by how many links they have, wiki links are curved accent lines and folder
// structure is a straight hairline. Hover a node to isolate its neighbours.
Rectangle {
    id: root
    color: AppTheme.graphBg
    clip: true
    focus: true

    // ---- public API (kept stable for Main.qml) ----
    property var graphData: ({ nodes: [], edges: [], linkCount: 0 })
    property real zoom: 1.0
    property bool labels: true

    readonly property int percent: Math.round(zoom * 100)
    readonly property int nodeCount: graphData.nodes ? graphData.nodes.length : 0
    readonly property int linkCount: graphData.linkCount || 0

    signal noteClicked(string path)
    signal closeRequested()

    // ---- view state ----
    property real panX: 0
    property real panY: 0
    property int hoverIdx: -1
    property var hoverSet: ({})
    property var adjacency: []
    property real reveal: 1
    readonly property real sizeScale: Math.pow(zoom, 0.25)

    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)) }

    function radiusOf(n) {
        if (n.type === "folder") return (n.depth || 0) === 0 ? 13 : 9
        if (n.type === "note") return 3.5 + Math.min(Math.sqrt(n.links || 0), 3.2) * 2.2
        return 3.5
    }

    function project(i) {
        const n = graphData.nodes ? graphData.nodes[i] : null
        if (!n) return { x: 0, y: 0 }
        const span = 0.9 * zoom
        const w = Math.min(width, height * 1.8)
        return {
            x: panX + width / 2 + (n.x - 0.5) * w * span,
            y: panY + height / 2 + (n.y - 0.5) * height * span
        }
    }

    function buildAdjacency() {
        const adj = []
        for (let i = 0; i < nodeCount; ++i) adj.push([])
        for (const e of (graphData.edges || [])) {
            adj[e.a].push(e.b)
            adj[e.b].push(e.a)
        }
        adjacency = adj
    }

    function zoomAt(f, mx, my) {
        const nz = clamp(zoom * f, 0.4, 3.0)
        const k = nz / zoom
        panX = mx - width / 2 - (mx - width / 2 - panX) * k
        panY = my - height / 2 - (my - height / 2 - panY) * k
        zoom = nz
    }
    function zoomIn() { zoomAt(1.15, width / 2, height / 2) }
    function zoomOut() { zoomAt(1 / 1.15, width / 2, height / 2) }
    function fit() { zoom = 1; panX = 0; panY = 0 }

    function centerCurrent() {
        const ns = graphData.nodes || []
        for (let i = 0; i < ns.length; ++i) {
            if (ns[i].current) {
                const p = project(i)
                panX += width / 2 - p.x
                panY += height / 2 - p.y
                break
            }
        }
    }

    function reload() {
        const g = vault.graph()
        if (g.nodes && g.nodes.length === 1) g.nodes[0].x = g.nodes[0].y = 0.5
        graphData = g
        buildAdjacency()
        hoverIdx = -1
        fit()
        edges.requestPaint()
        revealAnim.restart()
    }

    Component.onCompleted: reload()
    onVisibleChanged: if (visible) { reload(); forceActiveFocus() }

    onPanXChanged: edges.requestPaint()
    onPanYChanged: edges.requestPaint()
    onZoomChanged: edges.requestPaint()
    onHoverIdxChanged: {
        const s = {}
        if (hoverIdx >= 0 && adjacency[hoverIdx])
            for (const j of adjacency[hoverIdx]) s[j] = true
        hoverSet = s
        edges.requestPaint()
    }

    Connections { target: vault; function onTreeChanged() { edges.requestPaint() } }
    Connections {
        target: AppTheme
        function onDarkChanged() { edges.requestPaint() }
        function onAccentChanged() { edges.requestPaint() }
    }

    NumberAnimation {
        id: revealAnim
        target: root; property: "reveal"
        from: 0; to: 1
        duration: AppTheme.motionSlow
        easing.type: Easing.OutCubic
    }

    Keys.onPressed: (e) => {
        switch (e.key) {
        case Qt.Key_Plus: case Qt.Key_Equal: zoomIn(); e.accepted = true; break
        case Qt.Key_Minus: zoomOut(); e.accepted = true; break
        case Qt.Key_0: case Qt.Key_F: fit(); e.accepted = true; break
        case Qt.Key_C: centerCurrent(); e.accepted = true; break
        case Qt.Key_L: labels = !labels; e.accepted = true; break
        }
    }

    MouseArea {
        id: panArea
        anchors.fill: parent
        cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
        property real lastX: 0
        property real lastY: 0
        onPressed: (m) => { lastX = m.x; lastY = m.y; root.forceActiveFocus() }
        onPositionChanged: (m) => {
            root.panX += m.x - lastX
            root.panY += m.y - lastY
            lastX = m.x; lastY = m.y
        }
        onDoubleClicked: root.fit()
    }
    WheelHandler {
        onWheel: (e) => root.zoomAt(Math.pow(1.0015, e.angleDelta.y), e.x, e.y)
    }

    // dot grid, links and structure
    Canvas {
        id: edges
        anchors.fill: parent
        opacity: root.reveal
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            const ctx = getContext("2d")
            ctx.reset()

            // grid moves with the content so panning has a sense of surface
            const step = 28 * root.zoom
            if (step >= 12) {
                const x0 = ((root.panX + width / 2) % step + step) % step
                const y0 = ((root.panY + height / 2) % step + step) % step
                ctx.fillStyle = AppTheme.borderStrong
                ctx.globalAlpha = 0.4
                for (let x = x0; x < width; x += step)
                    for (let y = y0; y < height; y += step)
                        ctx.fillRect(x, y, 1.5, 1.5)
            }

            const es = root.graphData.edges || []
            const pts = []
            for (let i = 0; i < root.nodeCount; ++i) pts.push(root.project(i))
            const hov = root.hoverIdx

            // structure first, wiki links on top
            for (let pass = 0; pass < 2; ++pass) {
                for (const e of es) {
                    const isLink = e.type === "link"
                    if (isLink !== (pass === 1)) continue
                    const a = pts[e.a], b = pts[e.b]
                    if (!a || !b) continue
                    const related = hov < 0 || e.a === hov || e.b === hov
                    ctx.beginPath()
                    ctx.moveTo(a.x, a.y)
                    if (isLink) {
                        const dx = b.x - a.x, dy = b.y - a.y
                        const bend = 0.14
                        ctx.quadraticCurveTo((a.x + b.x) / 2 - dy * bend,
                                             (a.y + b.y) / 2 + dx * bend, b.x, b.y)
                        ctx.strokeStyle = AppTheme.accent
                        ctx.globalAlpha = related ? (hov < 0 ? 0.55 : 0.95) : 0.07
                        ctx.lineWidth = hov >= 0 && related ? 1.7 : 1.2
                    } else {
                        ctx.lineTo(b.x, b.y)
                        ctx.strokeStyle = AppTheme.graphEdge
                        ctx.globalAlpha = related ? (hov < 0 ? 0.5 : 0.85) : 0.06
                        ctx.lineWidth = 1
                    }
                    ctx.stroke()
                }
            }
            ctx.globalAlpha = 1
        }
    }

    Item {
        anchors.fill: parent
        opacity: root.reveal

        Repeater {
            model: root.graphData.nodes
            delegate: Item {
                id: node
                required property var modelData
                required property int index

                readonly property var pr: root.project(index)
                readonly property bool isFolder: modelData.type === "folder"
                readonly property bool isRoot: isFolder && (modelData.depth || 0) === 0
                readonly property bool isNote: modelData.type === "note"
                readonly property bool isHub: isNote && (modelData.links || 0) >= 3
                readonly property bool isOrphan: isNote && (modelData.links || 0) === 0
                readonly property bool isCurrent: modelData.current === true
                readonly property bool hovered: root.hoverIdx === index
                readonly property bool isNeighbor: root.hoverSet[index] === true
                readonly property bool inFocus: root.hoverIdx < 0 || hovered || isNeighbor
                readonly property real r: root.radiusOf(modelData) * root.sizeScale
                readonly property bool emphasized: hovered || isCurrent
                readonly property bool showLabel: hovered
                    || (root.labels && (isCurrent || isNeighbor || isRoot || isHub
                                        || (isFolder && root.zoom >= 0.8)
                                        || root.zoom >= 1.5))
                readonly property string title: isNote
                    ? String(modelData.label || "").replace(/\.md$/i, "")
                    : String(modelData.label || "")

                width: r * 2
                height: width
                x: pr.x - r
                y: pr.y - r
                z: hovered ? 900 : (isCurrent ? 800 : (isRoot ? 700 : (isHub ? 600 : 500)))
                opacity: inFocus ? 1 : 0.16
                Behavior on opacity { NumberAnimation { duration: AppTheme.motionFast } }

                // halo behind hubs and the open note
                Rectangle {
                    visible: node.isHub || node.isCurrent || node.hovered
                    anchors.centerIn: parent
                    width: parent.width + (node.isCurrent ? 18 : 12)
                    height: width
                    radius: width / 2
                    color: AppTheme.accent
                    opacity: node.isCurrent ? 0.2 : 0.12
                }

                Rectangle {
                    visible: node.isFolder
                    anchors.fill: parent
                    radius: node.isRoot ? AppTheme.radiusMd : AppTheme.radiusSm
                    color: node.isRoot ? AppTheme.accentSoft : AppTheme.nodeBg
                    border.color: node.isRoot ? AppTheme.accent : AppTheme.nodeBorder
                    border.width: node.isRoot ? 1.5 : 1
                    Icon {
                        anchors.centerIn: parent
                        kind: "folder"
                        size: node.isRoot ? 16 : 12
                        col: node.isRoot ? AppTheme.accent : AppTheme.muted
                    }
                }
                Rectangle {
                    visible: node.isNote
                    anchors.fill: parent
                    radius: width / 2
                    color: node.isCurrent ? AppTheme.accent
                         : node.isOrphan ? "transparent"
                         : node.isHub ? AppTheme.accentHover : AppTheme.accentFill
                    border.color: node.isCurrent ? AppTheme.fg
                                : node.isOrphan ? AppTheme.faint : "transparent"
                    border.width: 1.5
                }
                Rectangle {
                    visible: modelData.type === "other"
                    anchors.centerIn: parent
                    width: parent.width * 0.8; height: width
                    rotation: 45
                    radius: AppTheme.radiusXs
                    color: AppTheme.faint
                }

                Rectangle {
                    visible: node.showLabel
                    anchors { top: parent.bottom; topMargin: AppTheme.space2; horizontalCenter: parent.horizontalCenter }
                    width: labelRow.implicitWidth + (node.emphasized ? 14 : 0)
                    height: labelRow.implicitHeight + (node.emphasized ? 6 : 0)
                    radius: AppTheme.radiusSm
                    color: node.emphasized ? AppTheme.surface : "transparent"
                    border.color: node.emphasized ? AppTheme.borderStrong : "transparent"
                    border.width: 1

                    Row {
                        id: labelRow
                        anchors.centerIn: parent
                        spacing: AppTheme.space2
                        Text {
                            id: titleText
                            width: Math.min(implicitWidth, 180)
                            elide: Text.ElideRight
                            text: node.title
                            color: node.isCurrent ? AppTheme.accent
                                 : (node.isFolder ? AppTheme.fg : AppTheme.muted)
                            font.family: AppTheme.ui
                            font.pixelSize: node.emphasized ? AppTheme.fontSm : AppTheme.fontXs
                            font.weight: node.isFolder || node.emphasized ? Font.DemiBold : Font.Normal
                            style: node.emphasized ? Text.Normal : Text.Outline
                            styleColor: AppTheme.graphBg
                        }
                        Text {
                            visible: node.hovered && node.isNote && (modelData.links || 0) > 0
                            text: (modelData.links || 0) + ((modelData.links || 0) === 1 ? " link" : " links")
                            color: AppTheme.faint
                            font.family: AppTheme.ui
                            font.pixelSize: AppTheme.fontXs
                        }
                    }
                }

                MouseArea {
                    anchors { fill: parent; margins: -6 }
                    hoverEnabled: true
                    cursorShape: node.isNote ? Qt.PointingHandCursor : Qt.ArrowCursor
                    onEntered: root.hoverIdx = node.index
                    onExited: if (root.hoverIdx === node.index) root.hoverIdx = -1
                    onClicked: if (node.isNote) root.noteClicked(modelData.id)
                }
            }
        }
    }

    // ---- legend and hints ----
    component LegendItem: Row {
        property alias label: legendText.text
        default property alias swatch: holder.data
        spacing: AppTheme.space2
        Item { id: holder; width: 14; height: 14; anchors.verticalCenter: parent.verticalCenter }
        Text {
            id: legendText
            anchors.verticalCenter: parent.verticalCenter
            color: AppTheme.faint
            font.family: AppTheme.ui
            font.pixelSize: AppTheme.fontXs
        }
    }

    Row {
        visible: root.width >= 560 && root.nodeCount > 0
        anchors { left: parent.left; bottom: parent.bottom; margins: AppTheme.space3 }
        spacing: AppTheme.space4
        LegendItem {
            label: "Folder"
            Rectangle {
                anchors.centerIn: parent; width: 11; height: 11
                radius: AppTheme.radiusXs
                color: AppTheme.nodeBg; border.color: AppTheme.nodeBorder
            }
        }
        LegendItem {
            label: "Note"
            Rectangle { anchors.centerIn: parent; width: 8; height: 8; radius: width / 2; color: AppTheme.accentFill }
        }
        LegendItem {
            label: "Hub (3+ links)"
            Rectangle { anchors.centerIn: parent; width: 12; height: 12; radius: width / 2; color: AppTheme.accentHover }
        }
        LegendItem {
            label: "Unlinked"
            Rectangle {
                anchors.centerIn: parent; width: 8; height: 8; radius: width / 2
                color: "transparent"; border.color: AppTheme.faint; border.width: 1.5
            }
        }
        LegendItem {
            label: "Wiki link"
            Rectangle { anchors.centerIn: parent; width: 14; height: 1.5; color: AppTheme.accent }
        }
    }

    Text {
        visible: root.width >= 560 && root.nodeCount > 0
        anchors { right: parent.right; bottom: parent.bottom; margins: AppTheme.space3 }
        text: Math.abs(root.zoom - 1) > 0.005
            ? root.percent + "%  ·  double-click to reset"
            : "Scroll to zoom, drag to pan"
        color: AppTheme.faint
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontXs
    }

    Text {
        visible: root.nodeCount > 1 && root.linkCount === 0
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: AppTheme.space4 }
        text: "No wiki links yet. Type [[ in a note to link it to another."
        color: AppTheme.faint
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontSm
    }

    EmptyState {
        anchors.centerIn: parent
        visible: root.nodeCount === 0
        icon: "graph"
        title: "Nothing to graph yet"
        hint: "Create a note and it will appear here"
    }

    // ---- stats (top left) and tools (top right); the app header stays identical in every view
    Text {
        visible: root.nodeCount > 0 && root.width >= 760
        anchors { left: parent.left; top: parent.top; margins: AppTheme.gutter }
        height: AppTheme.ctrlLg
        verticalAlignment: Text.AlignVCenter
        text: root.nodeCount + " nodes · " + root.linkCount + " wiki links"
        color: AppTheme.muted
        font.family: AppTheme.ui
        font.pixelSize: AppTheme.fontSm
    }
    Rectangle {
        anchors { right: parent.right; top: parent.top; margins: AppTheme.gutter }
        width: tools.implicitWidth + AppTheme.space1 * 2
        height: AppTheme.ctrlLg
        radius: AppTheme.radiusLg                 // inner buttons: 12 - 4 = 8
        color: AppTheme.surface
        border.width: 1
        border.color: AppTheme.line
        Row {
            id: tools
            anchors.centerIn: parent
            ToolBtn { iconOnly: true; iconKind: "fit"; tip: "Fit (F)"; onClicked: root.fit() }
            ToolBtn { iconOnly: true; iconKind: "font"; tip: "Labels (L)"; active: root.labels; onClicked: root.labels = !root.labels }
        }
    }
}
