import QtQuick
import QtQuick.Controls

// The one button. Ghost by default; primary = filled accent; active = selected tint; danger = red.
// Height is always a control height from AppTheme (ctrlSm / ctrlMd / ctrlLg); radius follows the height.
Button {
    id: b

    property string iconKind: ""
    property string tip: ""
    property bool iconOnly: false
    property bool primary: false
    property bool danger: false
    property bool active: false
    property bool alignLeft: false       // left-align content (nav lists) instead of centering
    property real cornerRadius: height < AppTheme.ctrlMd ? AppTheme.radiusSm : AppTheme.radiusMd

    readonly property color fgColor: primary ? AppTheme.accentOn
                                   : danger ? AppTheme.danger
                                   : active ? AppTheme.accent : AppTheme.fg

    implicitHeight: AppTheme.ctrlMd
    implicitWidth: iconOnly ? implicitHeight : row.implicitWidth + AppTheme.space3 * 2
    Accessible.name: b.tip !== "" ? b.tip : (b.text !== "" ? b.text : b.iconKind)
    Accessible.role: Accessible.Button
    padding: 0
    hoverEnabled: true
    opacity: enabled ? 1 : 0.4
    font.family: AppTheme.ui
    font.pixelSize: AppTheme.fontMd

    background: Rectangle {
        radius: b.cornerRadius
        color: b.primary ? (b.down ? AppTheme.accentFill : (b.hovered ? AppTheme.accentHover : AppTheme.accentFill))
             : b.active ? AppTheme.accentSoft
             : b.down ? AppTheme.pressed
             : b.hovered ? (b.danger ? AppTheme.dangerSoft : AppTheme.hover) : "transparent"
        border.width: b.visualFocus ? 2 : 0
        border.color: AppTheme.focusRing
    }

    contentItem: Item {
        implicitWidth: row.implicitWidth
        implicitHeight: row.implicitHeight
        Row {
            id: row
            x: b.alignLeft ? AppTheme.space3 : Math.round((parent.width - width) / 2)
            anchors.verticalCenter: parent.verticalCenter
            spacing: AppTheme.space2
            Icon {
                visible: b.iconKind !== ""
                anchors.verticalCenter: parent.verticalCenter
                kind: b.iconKind
                col: b.fgColor
            }
            Text {
                visible: !b.iconOnly && b.text !== ""
                anchors.verticalCenter: parent.verticalCenter
                text: b.text
                color: b.fgColor
                font.family: b.font.family
                font.pixelSize: b.font.pixelSize
                font.weight: b.primary || b.active ? Font.DemiBold : Font.Normal
            }
        }
    }

    Tip { parent: b; text: b.tip; show: b.hovered && b.enabled }
}
