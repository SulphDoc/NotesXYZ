import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Settings sheet: a nav list on the left, one page on the right.
Rectangle {
    id: root
    property int page: 0
    signal openVaultRequested()
    signal replayWelcome()
    signal exportRequested()
    signal exportZipRequested()
    signal closeRequested()

    readonly property var pages: [
        { name: "General",    icon: "settings" },
        { name: "Appearance", icon: "palette" },
        { name: "Editor",     icon: "font" },
        { name: "Shortcuts",  icon: "keyboard" },
        { name: "About",      icon: "about" }
    ]

    width: Math.min(660, parent.width - AppTheme.space6 * 2)
    height: Math.min(460, parent.height - AppTheme.space6 * 2)
    color: AppTheme.surface
    radius: AppTheme.radiusLg
    border.width: 1
    border.color: AppTheme.borderStrong
    Elevation { radius: root.radius }
    MouseArea { anchors.fill: parent }

    // A group of controls under a heading. Children go into `items`.
    component Group: Column {
        property string title: ""
        default property alias items: body.data
        width: parent ? parent.width : 0
        spacing: AppTheme.space2
        SectionLabel { text: parent.title }
        Column { id: body; width: parent.width; spacing: AppTheme.space2 }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // ---- nav
        ColumnLayout {
            Layout.preferredWidth: 188
            Layout.fillHeight: true
            Layout.margins: AppTheme.space3
            spacing: AppTheme.space1

            Text {
                Layout.leftMargin: AppTheme.space3
                Layout.bottomMargin: AppTheme.space2
                Layout.topMargin: AppTheme.space1
                text: "Settings"
                color: AppTheme.fg
                font.family: AppTheme.ui
                font.pixelSize: AppTheme.fontXl
                font.weight: Font.DemiBold
            }
            Repeater {
                model: root.pages
                delegate: ToolBtn {
                    required property var modelData
                    required property int index
                    Layout.fillWidth: true
                    alignLeft: true
                    text: modelData.name
                    iconKind: modelData.icon
                    active: root.page === index
                    onClicked: root.page = index
                }
            }
            Item { Layout.fillHeight: true }
        }
        Rectangle { Layout.fillHeight: true; implicitWidth: 1; color: AppTheme.line }

        // ---- page
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: AppTheme.dialogPad
            spacing: AppTheme.space4

            RowLayout {
                Layout.fillWidth: true
                Text {
                    Layout.fillWidth: true
                    text: root.pages[root.page].name
                    color: AppTheme.fg
                    font.family: AppTheme.ui
                    font.pixelSize: AppTheme.fontXxl
                    font.weight: Font.Bold
                }
                ToolBtn { iconOnly: true; iconKind: "close"; tip: "Close (Esc)"; onClicked: root.closeRequested() }
            }

            StackLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                currentIndex: root.page

                // General
                Column {
                    spacing: AppTheme.space5
                    Group {
                        title: "Vault"
                        Row {
                            width: parent.width
                            spacing: AppTheme.space2
                            Icon { anchors.verticalCenter: parent.verticalCenter; kind: "folder"; col: AppTheme.muted }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                width: parent.width - 16 - AppTheme.space2 * 2 - openBtn.width
                                elide: Text.ElideMiddle
                                text: vault.root
                                color: AppTheme.fg
                                font.family: AppTheme.ui
                                font.pixelSize: AppTheme.fontMd
                            }
                            ToolBtn { id: openBtn; anchors.verticalCenter: parent.verticalCenter; text: "Open…"; onClicked: root.openVaultRequested() }
                        }
                        Text {
                            text: vault.noteCount + " notes · " + vault.totalWords + " words"
                            color: AppTheme.faint
                            font.family: AppTheme.ui
                            font.pixelSize: AppTheme.fontSm
                        }
                    }
                    Group {
                        title: "Saving"
                        AppCheckBox { text: "Save automatically"; checked: vault.autosave; onToggled: vault.autosave = checked }
                    }
                    Group {
                        title: "Other"
                        Row {
                            spacing: AppTheme.space2
                            ToolBtn { text: "Export note as HTML"; iconKind: "external"; onClicked: root.exportRequested() }
                            ToolBtn { text: "Back up all as ZIP"; iconKind: "folder_new"; onClicked: root.exportZipRequested() }
                            ToolBtn { text: "Replay welcome"; onClicked: root.replayWelcome() }
                        }
                    }
                }

                // Appearance
                Column {
                    spacing: AppTheme.space5
                    Group {
                        title: "Theme"
                        Segmented {
                            current: vault.dark ? 1 : 0
                            model: [{ icon: "sun", tip: "Light" }, { icon: "moon", tip: "Dark" }]
                            onPicked: (i) => vault.dark = (i === 1)
                        }
                    }
                    Group {
                        title: "Accent"
                        Row {
                            spacing: AppTheme.space3
                            Repeater {
                                model: AppTheme.palettes
                                delegate: Rectangle {
                                    id: swatch
                                    required property var modelData
                                    required property int index
                                    width: AppTheme.ctrlMd
                                    height: AppTheme.ctrlMd
                                    radius: width / 2
                                    color: AppTheme.dark ? modelData.df : modelData.lf
                                    border.width: vault.accent === index ? 2 : 0
                                    border.color: AppTheme.fg
                                    Icon { anchors.centerIn: parent; visible: vault.accent === swatch.index; kind: "check"; col: AppTheme.accentOn }
                                    MouseArea {
                                        id: swatchArea
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: vault.accent = swatch.index
                                    }
                                    Tip { parent: swatch; text: swatch.modelData.name; show: swatchArea.containsMouse }
                                }
                            }
                        }
                    }
                }

                // Editor
                Column {
                    spacing: AppTheme.space5
                    Group {
                        title: "Text size"
                        Row {
                            spacing: AppTheme.space2
                            ToolBtn { iconOnly: true; iconKind: "remove"; tip: "Smaller (Ctrl+-)"; onClicked: vault.fontSize = vault.fontSize - 1 }
                            Text {
                                width: 56
                                height: AppTheme.ctrlMd
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                text: vault.fontSize + " px"
                                color: AppTheme.fg
                                font.family: AppTheme.ui
                                font.pixelSize: AppTheme.fontMd
                            }
                            ToolBtn { iconOnly: true; iconKind: "add"; tip: "Larger (Ctrl+=)"; onClicked: vault.fontSize = vault.fontSize + 1 }
                        }
                    }
                    Group {
                        title: "Reading width"
                        Row {
                            spacing: AppTheme.space2
                            ToolBtn { iconOnly: true; iconKind: "remove"; tip: "Narrower"; onClicked: vault.readingWidth = vault.readingWidth - 40 }
                            Text {
                                width: 64
                                height: AppTheme.ctrlMd
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                text: vault.readingWidth + " px"
                                color: AppTheme.fg
                                font.family: AppTheme.ui
                                font.pixelSize: AppTheme.fontMd
                            }
                            ToolBtn { iconOnly: true; iconKind: "add"; tip: "Wider"; onClicked: vault.readingWidth = vault.readingWidth + 40 }
                        }
                    }
                    Group {
                        title: "Typewriter mode"
                        AppCheckBox {
                            text: "Keep the current line centred"
                            checked: vault.typewriter
                            onToggled: vault.typewriter = checked
                        }
                    }
                }

                // Shortcuts
                ScrollView {
                    id: shortcutScroll
                    clip: true
                    ScrollBar.vertical: ThinScrollBar {}
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                    ShortcutList { width: shortcutScroll.availableWidth }
                }

                // About
                Column {
                    spacing: AppTheme.space2
                    Logo { size: 64 }
                    Text {
                        text: "NoteXYZ"
                        color: AppTheme.fg
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontXl
                        font.weight: Font.DemiBold
                    }
                    Text {
                        text: "Plain Markdown notes in a folder you own."
                        color: AppTheme.muted
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontMd
                    }
                    Text {
                        text: "Icons: Adwaita (CC-BY-SA 3.0 / LGPL 3)"
                        color: AppTheme.faint
                        font.family: AppTheme.ui
                        font.pixelSize: AppTheme.fontSm
                    }
                }
            }
        }
    }
}
