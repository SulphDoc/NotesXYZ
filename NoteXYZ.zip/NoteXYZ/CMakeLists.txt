cmake_minimum_required(VERSION 3.21)
project(NotesApp VERSION 0.2 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)

find_package(Qt6 6.5 REQUIRED COMPONENTS Core Gui Quick QuickControls2)

qt_standard_project_setup(REQUIRES 6.5)

qt_add_executable(notes
    src/main.cpp
    src/app.h
    src/app.cpp
    src/docrender.h
    src/docrender.cpp
    src/vault.h
    src/vault_core.cpp
    src/vault_files.cpp
    src/vault_prefs.cpp
    src/vault_graph.cpp
)

# Every new .qml component must be listed here.
qt_add_qml_module(notes
    URI NotesApp
    VERSION 1.0
    QML_FILES
        qml/Main.qml
        qml/ActivityDialog.qml
        qml/AppCheckBox.qml
        qml/AppDialog.qml
        qml/AppField.qml
        qml/CommandPalette.qml
        qml/DeleteDialog.qml
        qml/DocPane.qml
        qml/Elevation.qml
        qml/EmptyState.qml
        qml/Graph.qml
        qml/Icon.qml
        qml/Keycap.qml
        qml/Logo.qml
        qml/NameDialog.qml
        qml/Onboarding.qml
        qml/OutlinePanel.qml
        qml/Scrim.qml
        qml/SectionLabel.qml
        qml/Segmented.qml
        qml/Settings.qml
        qml/ShortcutList.qml
        qml/Sidebar.qml
        qml/Start.qml
        qml/StatusBar.qml
        qml/TextPane.qml
        qml/ThinScrollBar.qml
        qml/Tip.qml
        qml/Toast.qml
        qml/ToolBtn.qml
        qml/TopBar.qml
    RESOURCES
        qml/ThemeObject.qml
        qml/fonts/NoteXYZIcons.ttf
        qml/images/logo-color.png
        qml/images/logo-black.png
        qml/images/logo-white.png
        qml/images/mark-color.svg
        qml/images/mark-black.svg
        qml/images/mark-white.svg
)

target_link_libraries(notes PRIVATE Qt6::Core Qt6::Gui Qt6::Quick Qt6::QuickControls2)

install(TARGETS notes RUNTIME DESTINATION bin)
